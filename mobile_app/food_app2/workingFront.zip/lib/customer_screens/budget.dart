// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'dart:convert';
// import 'package:flutter_secure_storage/flutter_secure_storage.dart';
//
// void main() => runApp(const SmartCanteenApp());
//
// class SmartCanteenApp extends StatelessWidget {
//   const SmartCanteenApp({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       home: const LoginScreen(),
//     );
//   }
// }
//
// // ---------------- LOGIN SCREEN ----------------
// class LoginScreen extends StatefulWidget {
//   const LoginScreen({super.key});
//
//   @override
//   State<LoginScreen> createState() => _LoginScreenState();
// }
//
// class _LoginScreenState extends State<LoginScreen> {
//   final storage = const FlutterSecureStorage();
//   final _usernameController = TextEditingController();
//   final _passwordController = TextEditingController();
//   bool _loading = false;
//   String _error = '';
//
//   Future<void> _login() async {
//     setState(() {
//       _loading = true;
//       _error = '';
//     });
//
//     final response = await http.post(
//       Uri.parse('http://192.168.56.1:8081/api/auth/login'),
//       headers: {'Content-Type': 'application/json'},
//       body: jsonEncode({
//         'username': _usernameController.text.trim(),
//         'password': _passwordController.text.trim(),
//       }),
//     );
//
//     setState(() => _loading = false);
//
//     if (response.statusCode == 200) {
//       final data = jsonDecode(response.body);
//       // Adjust keys as per your backend's response
//       final token = data['token'] ?? data['accessToken'];
//       final userId = data['userId']?.toString() ?? data['id']?.toString();
//       if (token != null && userId != null) {
//         await storage.write(key: 'jwt_token', value: token);
//         await storage.write(key: 'customer_id', value: userId);
//         Navigator.pushReplacement(
//           context,
//           MaterialPageRoute(builder: (_) => const BudgetDashboard()),
//         );
//       } else {
//         setState(() => _error = 'Invalid login response');
//       }
//     } else {
//       setState(() => _error = 'Invalid username or password');
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text('Smart Canteen Login')),
//       body: Padding(
//         padding: const EdgeInsets.all(24),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             const Icon(Icons.person, size: 80, color: Colors.deepPurple),
//             const SizedBox(height: 16),
//             TextField(
//               controller: _usernameController,
//               decoration: const InputDecoration(
//                 labelText: 'Username',
//                 prefixIcon: Icon(Icons.person),
//               ),
//             ),
//             const SizedBox(height: 12),
//             TextField(
//               controller: _passwordController,
//               obscureText: true,
//               decoration: const InputDecoration(
//                 labelText: 'Password',
//                 prefixIcon: Icon(Icons.lock),
//               ),
//             ),
//             const SizedBox(height: 24),
//             ElevatedButton(
//               onPressed: _loading ? null : _login,
//               child: _loading
//                   ? const CircularProgressIndicator()
//                   : const Text('Login'),
//             ),
//             if (_error.isNotEmpty)
//               Padding(
//                 padding: const EdgeInsets.only(top: 16),
//                 child: Text(_error, style: const TextStyle(color: Colors.red)),
//               ),
//           ],
//         ),
//       ),
//     );
//   }
// }
//
// // ---------------- DASHBOARD SCREEN ----------------
// class BudgetDashboard extends StatefulWidget {
//   const BudgetDashboard({super.key});
//
//   @override
//   _BudgetDashboardState createState() => _BudgetDashboardState();
// }
//
// class _BudgetDashboardState extends State<BudgetDashboard> {
//   final storage = const FlutterSecureStorage();
//   double totalIncome = 4500;
//   double totalExpense = 2176.44;
//   double plannedBudget = 4500;
//   final String _baseUrl = 'http://192.168.56.1:8081/api/topup';
//   final _amountController = TextEditingController();
//   String? _jwtToken;
//   int? _customerId;
//
//   List<Map<String, dynamic>> expenses = [
//     {"name": "Lunch", "amount": 1700.00, "icon": Icons.home, "color": Colors.green},
//     {"name": "Snacks", "amount": 126.15, "icon": Icons.favorite, "color": Colors.pink},
//   ];
//
//   @override
//   void initState() {
//     super.initState();
//     _loadAuthData();
//   }
//
//   Future<void> _loadAuthData() async {
//     _jwtToken = await storage.read(key: 'jwt_token');
//     final id = await storage.read(key: 'customer_id');
//     setState(() {
//       _customerId = int.tryParse(id ?? '');
//     });
//   }
//
//   Future<void> _sendTopUpRequest(double amount) async {
//     // Always reload the latest token before sending request
//     await _loadAuthData();
//
//     if (_jwtToken == null) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('Please login first')),
//       );
//       return;
//     }
//
//     try {
//       final response = await http.post(
//         Uri.parse('$_baseUrl/request'),
//         headers: {
//           'Content-Type': 'application/json',
//           'Authorization': 'Bearer $_jwtToken',
//         },
//         body: jsonEncode({
//           'amount': amount, // Only amount is needed
//         }),
//       );
//
//       if (response.statusCode == 200) {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(content: Text('Top-up request sent to merchant!')),
//         );
//       } else {
//         ScaffoldMessenger.of(context).showSnackBar(
//           SnackBar(content: Text('Failed: ${response.body}')),
//         );
//       }
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Error: $e')),
//       );
//     }
//   }
//
//   void _showTopUpDialog(BuildContext context) {
//     final TextEditingController amountController = TextEditingController();
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('Request Top-Up'),
//         content: TextField(
//           controller: amountController,
//           keyboardType: TextInputType.number,
//           decoration: const InputDecoration(labelText: 'Amount'),
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context),
//             child: const Text('Cancel'),
//           ),
//           TextButton(
//             onPressed: () async {
//               final amount = double.tryParse(amountController.text);
//               if (amount == null || amount <= 0) {
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   const SnackBar(content: Text('Enter a valid amount')),
//                 );
//                 return;
//               }
//               // Send request
//               final token = await storage.read(key: 'jwt_token');
//               final response = await http.post(
//                 Uri.parse('http://YOUR_BACKEND/api/topup/request'),
//                 headers: {
//                   'Authorization': 'Bearer $token',
//                   'Content-Type': 'application/json',
//                 },
//                 body: jsonEncode({'amount': amount}),
//               );
//               if (response.statusCode == 200) {
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   const SnackBar(content: Text('Request sent!')),
//                 );
//               } else {
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   SnackBar(content: Text('Failed: ${response.body}')),
//                 );
//               }
//               Navigator.pop(context);
//             },
//             child: const Text('Send'),
//           ),
//         ],
//       ),
//     );
//   }
//
//
//   @override
//   Widget build(BuildContext context) {
//     double leftToSpend = totalIncome - totalExpense;
//     double spendProgress = totalExpense / plannedBudget;
//
//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: AppBar(
//         backgroundColor: Colors.deepPurple,
//         title: const Text("Smart Canteen Budget"),
//         actions: [
//           IconButton(
//             icon: const Icon(Icons.logout),
//             onPressed: () async {
//               await storage.deleteAll();
//               if (mounted) {
//                 Navigator.pushAndRemoveUntil(
//                   context,
//                   MaterialPageRoute(builder: (_) => const LoginScreen()),
//                       (route) => false,
//                 );
//               }
//             },
//           ),
//         ],
//       ),
//       body: SingleChildScrollView(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             _buildBalanceCard(leftToSpend),
//             const SizedBox(height: 20),
//             _buildProgressBar(leftToSpend, spendProgress),
//             const SizedBox(height: 20),
//             const Text(
//               "Expenses",
//               style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
//             ),
//             ...expenses.map((e) => _buildExpenseItem(e)),
//           ],
//         ),
//       ),
//       bottomNavigationBar: BottomNavigationBar(
//         items: const [
//           BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
//           BottomNavigationBarItem(
//             icon: Icon(Icons.calendar_today),
//             label: "Calendar",
//           ),
//           BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: "Stats"),
//           BottomNavigationBarItem(
//             icon: Icon(Icons.settings),
//             label: "Settings",
//           ),
//         ],
//         selectedItemColor: Colors.deepPurple,
//       ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: () => _showTopUpDialog(context),
//         backgroundColor: Colors.deepPurple,
//         child: const Icon(Icons.add),
//       ),
//     );
//   }
//
//   Widget _buildBalanceCard(double leftToSpend) {
//     return Container(
//       padding: const EdgeInsets.all(20),
//       decoration: BoxDecoration(
//         color: Colors.deepPurple,
//         borderRadius: BorderRadius.circular(20),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const Text("Default", style: TextStyle(color: Colors.white70)),
//           const SizedBox(height: 10),
//           Text(
//             "\$${leftToSpend.toStringAsFixed(2)}",
//             style: const TextStyle(
//               fontSize: 32,
//               color: Colors.white,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//           const SizedBox(height: 10),
//           Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               Row(
//                 children: [
//                   const Icon(Icons.trending_down, color: Colors.red),
//                   const SizedBox(width: 5),
//                   Text(
//                     "Expense: \$${totalExpense.toStringAsFixed(2)}",
//                     style: const TextStyle(color: Colors.white),
//                   ),
//                 ],
//               ),
//               Row(
//                 children: [
//                   const Icon(Icons.trending_up, color: Colors.green),
//                   const SizedBox(width: 5),
//                   Text(
//                     "Income: \$${totalIncome.toStringAsFixed(2)}",
//                     style: const TextStyle(color: Colors.white),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }
//
//   Widget _buildProgressBar(double leftToSpend, double progress) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         const Text("Left to Spend", style: TextStyle(fontWeight: FontWeight.w500)),
//         const SizedBox(height: 5),
//         Text(
//           "\$${leftToSpend.toStringAsFixed(2)} out of \$${plannedBudget.toStringAsFixed(2)}",
//         ),
//         const SizedBox(height: 10),
//         LinearProgressIndicator(
//           value: progress,
//           backgroundColor: Colors.grey[300],
//           valueColor: const AlwaysStoppedAnimation<Color>(Colors.lightGreen),
//           minHeight: 10,
//         ),
//       ],
//     );
//   }
//
//   Widget _buildExpenseItem(Map<String, dynamic> e) {
//     return ListTile(
//       leading: Icon(e['icon'], color: e['color']),
//       title: Text(e['name']),
//       trailing: Text("\$${e['amount'].toStringAsFixed(2)}"),
//     );
//   }
// }


import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class BudgetDashboard extends StatefulWidget {
  const BudgetDashboard({super.key});

  @override
  State<BudgetDashboard> createState() => _BudgetDashboardState();
}

class _BudgetDashboardState extends State<BudgetDashboard> {
  final storage = const FlutterSecureStorage();
  double _balance = 0.0;
  bool _loading = false;
  List<dynamic> _requests = [];

  Future<void> _fetchBalance() async {
    setState(() => _loading = true);
    try {
      final token = await storage.read(key: 'jwt_token');
      final response = await http.get(
        Uri.parse('http://192.168.56.1:8081/api/topup/balance'),
        headers: {'Authorization': 'Bearer $token'},
      );
      if (response.statusCode == 200) {
        setState(() => _balance = double.parse(response.body));
      }
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _fetchRequests() async {
    final token = await storage.read(key: 'jwt_token');
    final response = await http.get(
      Uri.parse('http://192.168.56.1:8081/api/topup/my-requests'),
      headers: {'Authorization': 'Bearer $token'},
    );
    if (response.statusCode == 200) {
      setState(() {
        _requests = jsonDecode(response.body);
      });
    }
  }

  Future<void> _deleteRequest(int requestId) async {
    final token = await storage.read(key: 'jwt_token');
    final response = await http.delete(
      Uri.parse('http://192.168.56.1:8081/api/topup/request/$requestId'),
      headers: {'Authorization': 'Bearer $token'},
    );
    if (response.statusCode == 204) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Request deleted')),
      );
      _fetchRequests();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to delete request')),
      );
    }
  }

  void _showTopUpDialog(BuildContext context) {
    final TextEditingController amountController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Request Top-Up'),
        content: TextField(
          controller: amountController,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Amount'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              final amount = double.tryParse(amountController.text);
              if (amount == null || amount <= 0) return;

              final token = await storage.read(key: 'jwt_token');
              final response = await http.post(
                Uri.parse('http://192.168.56.1:8081/api/topup/request'),
                headers: {
                  'Authorization': 'Bearer $token',
                  'Content-Type': 'application/json',
                },
                body: jsonEncode({'amount': amount}),
              );

              if (response.statusCode == 200) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Request sent!')),
                );
                _fetchRequests();
                _fetchBalance();
              }
              Navigator.pop(context);
            },
            child: const Text('Send'),
          ),
        ],
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _fetchBalance();
    _fetchRequests();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Budget Dashboard")),
      body: Column(
        children: [
          const SizedBox(height: 20),
          Text(
            "Credit Balance: \$${_balance.toStringAsFixed(2)}",
            style: const TextStyle(fontSize: 24),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () => _showTopUpDialog(context),
            child: const Text('Request Top-Up'),
          ),
          const SizedBox(height: 20),
          const Divider(),
          const Text("Your Top-Up Requests", style: TextStyle(fontWeight: FontWeight.bold)),
          Expanded(
            child: _requests.isEmpty
                ? const Center(child: Text("No requests yet"))
                : ListView.builder(
              itemCount: _requests.length,
              itemBuilder: (context, index) {
                final req = _requests[index];
                return Card(
                  child: ListTile(
                    title: Text("Amount: \$${req['amount']} (PIN: ${req['pin']})"),
                    subtitle: Text("Status: ${req['status']}"),
                    trailing: req['status'] == 'PENDING'
                        ? IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _deleteRequest(req['id']),
                    )
                        : null,
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

