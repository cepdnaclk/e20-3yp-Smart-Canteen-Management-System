import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() => runApp(const TopUpPage());

class TopUpPage extends StatelessWidget {
  const TopUpPage({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Top Up Requests',
      theme: ThemeData(primarySwatch: Colors.orange, useMaterial3: true),
      home: const MerchantTopUpRequestsPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class TopUpRequest {
  final String id;
  final String customerName;
  final double amount;
  final String status;
  final DateTime requestTime;
  final String pin;

  TopUpRequest({
    required this.id,
    required this.customerName,
    required this.amount,
    required this.status,
    required this.requestTime,
    required this.pin,
  });

  factory TopUpRequest.fromJson(Map<String, dynamic> json) {
    return TopUpRequest(
      id: json['id'].toString(),
      customerName: json['customerId'].toString(),
      amount: json['amount'] is double
          ? json['amount']
          : (json['amount'] as num).toDouble(),
      status: json['status'],
      requestTime: DateTime.parse(json['requestTime']),
      pin: json['pin'] ?? '', // Ensure pin is included
    );
  }
}

class MerchantTopUpRequestsPage extends StatefulWidget {
  const MerchantTopUpRequestsPage({super.key});

  @override
  State<MerchantTopUpRequestsPage> createState() => _MerchantTopUpRequestsPageState();
}

class _MerchantTopUpRequestsPageState extends State<MerchantTopUpRequestsPage> {
  List<TopUpRequest> _requests = [];
  bool _loading = false;
  String _errorMessage = '';
  final storage = const FlutterSecureStorage();

  final String _baseUrl = '192.168.56.1:8081topup';

  Future<void> _fetchRequests() async {
    setState(() {
      _loading = true;
      _errorMessage = '';
    });

    try {
      final token = await storage.read(key: 'jwt_token');
      final response = await http.get(
        Uri.parse('$_baseUrl/pending'),
        headers: {'Authorization': 'Bearer $token'},
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        setState(() {
          _requests = data.map((json) => TopUpRequest.fromJson(json)).toList();
        });
      } else {
        setState(() => _errorMessage = 'Failed to load requests');
      }
    } catch (e) {
      setState(() => _errorMessage = 'No pending requests');
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _respondToRequest(String requestId, bool approve) async {
    // Show PIN entry dialog
    final pinController = TextEditingController();
    final String? enteredPin = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(approve ? 'Approve Request' : 'Reject Request'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Enter 4-digit PIN from customer:'),
            const SizedBox(height: 10),
            TextField(
              controller: pinController,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              maxLength: 4,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: '1234',
                counterText: '',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, null),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (pinController.text.length == 4) {
                Navigator.pop(context, pinController.text);
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Please enter a 4-digit PIN')),
                );
              }
            },
            child: const Text('Submit'),
          ),
        ],
      ),
    );

    if (enteredPin == null || enteredPin.length != 4) return;

    setState(() => _loading = true);

    try {
      final token = await storage.read(key: 'jwt_token');
      final url = '$_baseUrl/respond/$requestId?approve=$approve&pin=$enteredPin';
      final response = await http.post(
        Uri.parse(url),
        headers: {'Authorization': 'Bearer $token'},
      );

      if (response.statusCode == 200) {
        await _fetchRequests(); // Refresh list after response
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(approve ? 'Top-up approved!' : 'Top-up rejected!'), backgroundColor: Colors.green),
        );
      } else {
        setState(() => _errorMessage = 'Action failed');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Action failed'), backgroundColor: Colors.red),
        );
      }
    } catch (e) {
      setState(() => _errorMessage = 'Error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    _fetchRequests();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pending Top-Up Requests'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _fetchRequests,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage.isNotEmpty
          ? Center(child: Text(_errorMessage))
          : ListView.builder(
        itemCount: _requests.length,
        itemBuilder: (context, index) {
          final request = _requests[index];
          return Card(
            margin: const EdgeInsets.all(8),
            child: ListTile(
              title: Text('Customer: ${request.customerName}'),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Amount: \$${request.amount.toStringAsFixed(2)}'),
                  Text('Status: ${request.status}'),
                  Text('Requested: ${request.requestTime}'),
                  if (request.status == 'PENDING')
                    Text('PIN IS REQUIRED',
                        style: const TextStyle(
                            color: Colors.blue,
                            fontWeight: FontWeight.bold)),
                ],
              ),
              trailing: request.status == 'PENDING'
                  ? Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.check, color: Colors.green),
                    onPressed: () => _respondToRequest(request.id, true),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.red),
                    onPressed: () => _respondToRequest(request.id, false),
                  ),
                ],
              )
                  : null,
            ),
          );
        },
      ),
    );
  }
}
