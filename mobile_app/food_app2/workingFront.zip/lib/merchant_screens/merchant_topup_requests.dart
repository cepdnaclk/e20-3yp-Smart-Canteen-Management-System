import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class MerchantTopUpRequestsPage extends StatefulWidget {
  const MerchantTopUpRequestsPage({super.key});

  @override
  State<MerchantTopUpRequestsPage> createState() => _MerchantTopUpRequestsPageState();
}

class _MerchantTopUpRequestsPageState extends State<MerchantTopUpRequestsPage> {
  final storage = const FlutterSecureStorage();
  List<dynamic> _requests = [];
  bool _loading = false;
  bool _isProcessing = false;

  Future<void> _fetchRequests() async {
    setState(() => _loading = true);
    try {
      final token = await storage.read(key: 'jwt_token');
      final response = await http.get(
        Uri.parse('http://192.168.56.1:8081/api/topup/pending'),
        headers: {'Authorization': 'Bearer $token'},
      );
      if (response.statusCode == 200) {
        setState(() => _requests = jsonDecode(response.body));
      } else {
        _showError('Failed to load requests');
      }
    } catch (e) {
      _showError('Network error: $e');
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _respondToRequest(String requestId, bool approve) async {
    // Show PIN dialog
    String? enteredPin = await showDialog<String>(
      context: context,
      builder: (context) {
        final pinController = TextEditingController();
        return AlertDialog(
          title: Text(approve ? 'Approve Request' : 'Reject Request'),
          content: TextField(
            controller: pinController,
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            maxLength: 4,
            decoration: const InputDecoration(
              labelText: 'Enter 4-digit PIN',
              border: OutlineInputBorder(),
              counterText: '',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, null),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                if (pinController.text.length == 4) {
                  Navigator.pop(context, pinController.text);
                } else {
                  // Show error in dialog
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Please enter a 4-digit PIN')),
                  );
                }
              },
              child: const Text('Submit'),
            ),
          ],
        );
      },
    );

    if (enteredPin == null || enteredPin.length != 4) return;

    setState(() => _isProcessing = true);

    try {
      final token = await storage.read(key: 'jwt_token');
      if (token == null) {
        _showError('Authentication required');
        setState(() => _isProcessing = false);
        return;
      }

      final response = await http.post(
        Uri.parse('http://192.168.56.1:8081/api/topup/respond/$requestId?approve=$approve&pin=$enteredPin'),
        headers: {'Authorization': 'Bearer $token'},
      );

      if (response.statusCode == 200) {
        _showSuccess(approve ? 'Top-up approved' : 'Top-up rejected');
        await _fetchRequests();
      } else {
        _handleErrorResponse(response);
      }
    } catch (e) {
      _showError('Network error: $e');
    } finally {
      setState(() => _isProcessing = false);
    }
  }

  void _handleErrorResponse(http.Response response) {
    try {
      final errorData = jsonDecode(response.body);
      final errorMessage = errorData['error'] ?? errorData['message'] ?? 'Action failed';
      _showError(errorMessage);
    } catch (e) {
      _showError('Unknown error: ${response.body}');
    }
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('✅ $message'),
        backgroundColor: Colors.green,
      ),
    );
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('🚨 $message'),
        backgroundColor: Colors.red,
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _fetchRequests();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pending Top-Ups'),
        actions: [
          IconButton(
            icon: _loading
                ? const CircularProgressIndicator(color: Colors.white)
                : const Icon(Icons.refresh),
            onPressed: _loading ? null : _fetchRequests,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: _requests.length,
        itemBuilder: (context, index) {
          final request = _requests[index];
          return Card(
            margin: const EdgeInsets.all(8),
            child: ListTile(
              title: Text('Amount: \$${request['amount']}'),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Customer: ${request['customerId']}'),
                  Text('Status: ${request['status']}'),
                  if (request['status'] == 'PENDING')
                    Text('PIN: ${request['pin']}',
                        style: TextStyle(
                            color: Colors.blue[700],
                            fontWeight: FontWeight.bold)),
                ],
              ),
              trailing: request['status'] == 'PENDING'
                  ? Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: _isProcessing
                        ? const CircularProgressIndicator()
                        : const Icon(Icons.check, color: Colors.green),
                    onPressed: _isProcessing
                        ? null
                        : () => _respondToRequest(
                        request['id'].toString(), true),
                  ),
                  IconButton(
                    icon: _isProcessing
                        ? const CircularProgressIndicator()
                        : const Icon(Icons.close, color: Colors.red),
                    onPressed: _isProcessing
                        ? null
                        : () => _respondToRequest(
                        request['id'].toString(), false),
                  ),
                ],
              )
                  : null,
            ),
          );
        },
      ),
    );
  }
}
