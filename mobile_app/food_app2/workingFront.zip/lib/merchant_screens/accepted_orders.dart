import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

// --- Order Model ---
class Order {
  final String id;
  final String email;
  final DateTime orderTime;
  final DateTime? scheduledTime;
  final Map<String, int> items;
  final double totalAmount;
  final String status;

  Order({
    required this.id,
    required this.email,
    required this.orderTime,
    this.scheduledTime,
    required this.items,
    required this.totalAmount,
    required this.status,
  });

  factory Order.fromJson(Map<String, dynamic> json) {
    return Order(
      id: json['id'].toString(),
      email: json['email'],
      orderTime: DateTime.parse(json['orderTime']),
      scheduledTime: json['scheduledTime'] != null
          ? DateTime.parse(json['scheduledTime'])
          : null,
      items: Map<String, int>.from(json['items']),
      totalAmount: (json['totalAmount'] as num).toDouble(),
      status: json['status'],
    );
  }
}

// --- Order Service ---
class OrderService {
  static const String baseUrl = 'http://192.168.56.1:8081/api/orders';

  Future<List<Order>> fetchOrdersByStatus(String status) async {
    final response = await http.get(Uri.parse('$baseUrl/merchant/$status'));
    if (response.statusCode == 200) {
      List<dynamic> data = json.decode(response.body);
      return data.map((json) => Order.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load $status orders');
    }
  }

  Future<void> acceptOrder(String orderId) async {
    final response = await http.put(
      Uri.parse('$baseUrl/$orderId/accept'),
      headers: {'Content-Type': 'application/json'},
    );
    if (response.statusCode != 200) {
      throw Exception('Failed to accept order');
    }
  }

  Future<void> completeOrder(String orderId) async {
    final response = await http.put(
      Uri.parse('$baseUrl/$orderId/complete'),
      headers: {'Content-Type': 'application/json'},
    );
    if (response.statusCode != 200) {
      throw Exception('Failed to complete order');
    }
  }
}

// --- Accepted Orders Screen ---
class AcceptedOrdersScreen extends StatefulWidget {
  const AcceptedOrdersScreen({super.key});

  @override
  _AcceptedOrdersScreenState createState() => _AcceptedOrdersScreenState();
}

class _AcceptedOrdersScreenState extends State<AcceptedOrdersScreen> {
  final OrderService _orderService = OrderService();
  late Future<List<Order>> _acceptedOrders;

  @override
  void initState() {
    super.initState();
    _refreshAcceptedOrders();
  }

  void _refreshAcceptedOrders() {
    setState(() {
      _acceptedOrders = _orderService.fetchOrdersByStatus('accepted');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Accepted Orders'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context).pop(); // Navigate back to the previous page
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refreshAcceptedOrders,
          ),
        ],
      ),
      body: FutureBuilder<List<Order>>(
        future: _acceptedOrders,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          final orders = snapshot.data!;
          if (orders.isEmpty) {
            return const Center(child: Text('No accepted orders'));
          }
          return ListView.builder(
            itemCount: orders.length,
            itemBuilder: (context, index) {
              final order = orders[index];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Order #${order.id}',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 5),
                      Text('Customer: ${order.email}'),
                      Text('Date: ${order.orderTime.toLocal()}'),
                      const SizedBox(height: 10),
                      Align(
                        alignment: Alignment.centerRight,
                        child: ElevatedButton(
                          onPressed: () async {
                            try {
                              await _orderService.completeOrder(order.id);
                              _refreshAcceptedOrders();
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Order completed')),
                              );
                            } catch (e) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Error: $e')),
                              );
                            }
                          },
                          child: const Text('Complete'),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}