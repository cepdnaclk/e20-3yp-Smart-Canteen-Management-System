import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'accepted_orders.dart';

// --- Order Model ---
class Order {
  final String id;
  final String email;
  final DateTime orderTime;
  final DateTime? scheduledTime;
  final Map<String, int> items;
  final double totalAmount;
  final String status;

  Order({
    required this.id,
    required this.email,
    required this.orderTime,
    this.scheduledTime,
    required this.items,
    required this.totalAmount,
    required this.status,
  });

  factory Order.fromJson(Map<String, dynamic> json) {
    return Order(
      id: json['id'].toString(),
      email: json['email'],
      orderTime: DateTime.parse(json['orderTime']),
      scheduledTime: json['scheduledTime'] != null
          ? DateTime.parse(json['scheduledTime'])
          : null,
      items: Map<String, int>.from(json['items']),
      totalAmount: (json['totalAmount'] as num).toDouble(),
      status: json['status'],
    );
  }
}

// --- Order Service ---
class OrderService {
  static const String baseUrl = 'http://192.168.56.1:8081/api/orders';

  Future<List<Order>> fetchOrdersByStatus(String status) async {
    final response = await http.get(Uri.parse('$baseUrl/merchant/$status'));
    if (response.statusCode == 200) {
      List<dynamic> data = json.decode(response.body);
      return data.map((json) => Order.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load $status orders');
    }
  }

  Future<void> acceptOrder(String orderId) async {
    final response = await http.put(
      Uri.parse('$baseUrl/$orderId/accept'),
      headers: {'Content-Type': 'application/json'},
    );
    if (response.statusCode != 200) {
      throw Exception('Failed to accept order');
    }
  }

  Future<void> completeOrder(String orderId) async {
    final response = await http.put(
      Uri.parse('$baseUrl/$orderId/complete'),
      headers: {'Content-Type': 'application/json'},
    );
    if (response.statusCode != 200) {
      throw Exception('Failed to complete order');
    }
  }
}

// --- Pending Orders Screen ---
class PendingOrdersScreen extends StatefulWidget {
  @override
  _PendingOrdersScreenState createState() => _PendingOrdersScreenState();
}

class _PendingOrdersScreenState extends State<PendingOrdersScreen> {
  final OrderService _orderService = OrderService();
  late Future<List<Order>> _pendingOrders;

  @override
  void initState() {
    super.initState();
    _refreshOrders();
  }

  void _refreshOrders() {
    setState(() {
      _pendingOrders = _orderService.fetchOrdersByStatus('pending');
    });
  }

  void _navigateToAcceptedOrders() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => const AcceptedOrdersScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pending Orders'),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _refreshOrders,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _navigateToAcceptedOrders,
        label: Text('Accepted Orders'),
        icon: Icon(Icons.assignment_turned_in),
      ),
      body: FutureBuilder<List<Order>>(
        future: _pendingOrders,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          final orders = snapshot.data!;
          if (orders.isEmpty) {
            return Center(child: Text('No pending orders'));
          }
          return ListView.builder(
            itemCount: orders.length,
            itemBuilder: (context, index) {
              final order = orders[index];
              return Card(
                margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                child: Padding(
                  padding: EdgeInsets.all(10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Order #${order.id}',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      SizedBox(height: 5),
                      Text('Customer: ${order.email}'),
                      Text('Date: ${order.orderTime.toLocal()}'),
                      SizedBox(height: 10),
                      Align(
                        alignment: Alignment.centerRight,
                        child: ElevatedButton(
                          onPressed: () async {
                            try {
                              await _orderService.acceptOrder(order.id);
                              _refreshOrders();
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Order accepted')),
                              );
                            } catch (e) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Error: $e')),
                              );
                            }
                          },
                          child: Text('Accept'),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}