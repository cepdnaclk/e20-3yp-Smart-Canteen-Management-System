import 'package:flutter/material.dart';
import 'package:food_app/screens/admin/admin_profile_screen.dart';
import 'package:food_app/screens/admin/admin_reports_screen.dart';
import 'package:food_app/screens/admin/user_management_screen.dart';

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // In a real app, you'd fetch this data from ApiConstants.adminDashboard
    final dashboardData = {
      'totalUsers': 150,
      'totalOrders': 2340,
      'totalRevenue': 125000.00,
      'activeMerchants': 12,
    };

    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_outline),
            tooltip: 'My Profile',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminProfileScreen())),
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: 1.5,
            children: [
              _buildStatCard('Total Revenue', '₹${dashboardData['totalRevenue']}', Icons.monetization_on, Colors.green),
              _buildStatCard('Total Orders', '${dashboardData['totalOrders']}', Icons.receipt, Colors.blue),
              _buildStatCard('Total Users', '${dashboardData['totalUsers']}', Icons.people, Colors.orange),
              _buildStatCard('Active Merchants', '${dashboardData['activeMerchants']}', Icons.store, Colors.purple),
            ],
          ),
          const SizedBox(height: 24),
          _buildActionList(context),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Icon(icon, color: color, size: 32),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                Text(title, style: TextStyle(color: Colors.grey.shade600)),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _buildActionList(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Management Actions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Card(
          child: ListTile(
            leading: const Icon(Icons.manage_accounts),
            title: const Text('User Management'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const UserManagementScreen())),
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.bar_chart),
            title: const Text('Sales & Reports'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminReportsScreen())),
          ),
        ),
      ],
    );
  }
}