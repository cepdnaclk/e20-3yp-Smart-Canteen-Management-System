import 'package:flutter/material.dart';
import 'package:food_app/api/api_constants.dart';
import 'package:food_app/providers/auth_provider.dart';
import 'package:food_app/screens/merchant/manage_menu_screen.dart';
import 'package:food_app/screens/merchant/merchant_profile_screen.dart';
import 'package:food_app/screens/merchant/merchant_reports_screen.dart';
import 'package:food_app/screens/merchant/order_management_screen.dart';
import 'package:food_app/screens/merchant/top_up_requests_screen.dart';
import 'package:food_app/widgets/app_drawer.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class MerchantHomePage extends StatefulWidget {
  const MerchantHomePage({super.key});

  @override
  State<MerchantHomePage> createState() => _MerchantHomePageState();
}

class _MerchantHomePageState extends State<MerchantHomePage> {
  Future<Map<String, dynamic>>? _dashboardDataFuture;
  final _storage = const FlutterSecureStorage();

  @override
  void initState() {
    super.initState();
    _dashboardDataFuture = _fetchDashboardData();
  }

  Future<Map<String, dynamic>> _fetchDashboardData() async {
    final token = await _storage.read(key: 'jwt_token');
    final headers = {'Authorization': 'Bearer $token'};

    try {
      // Fetch daily revenue
      final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
      final revenueUri = Uri.parse('${ApiConstants.baseUrl}${ApiConstants.merchantReportsDaily}?date=$today');
      final revenueResponse = await http.get(revenueUri, headers: headers);

      // Fetch pending orders to get the count
      final pendingOrdersUri = Uri.parse(ApiConstants.baseUrl + ApiConstants.merchantOrdersByStatus + 'pending');
      final pendingOrdersResponse = await http.get(pendingOrdersUri, headers: headers);

      double dailyRevenue = 0.0;
      if (revenueResponse.statusCode == 200) {
        dailyRevenue = (jsonDecode(revenueResponse.body)['totalSales'] as num?)?.toDouble() ?? 0.0;
      }

      int newOrderCount = 0;
      if (pendingOrdersResponse.statusCode == 200) {
        newOrderCount = (jsonDecode(pendingOrdersResponse.body) as List).length;
      }

      return {
        'dailyRevenue': dailyRevenue,
        'newOrderCount': newOrderCount,
      };

    } catch (e) {
      // Return default values on error
      return {'dailyRevenue': 0.0, 'newOrderCount': 0};
    }
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Merchant Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle_outlined),
            tooltip: 'My Profile',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MerchantProfileScreen())),
          )
        ],
      ),
      drawer: const AppDrawer(),
      body: RefreshIndicator(
        onRefresh: () async {
          setState(() {
            _dashboardDataFuture = _fetchDashboardData();
          });
        },
        child: ListView(
          padding: const EdgeInsets.all(16.0),
          children: [
            _buildWelcomeHeader(authProvider.email ?? 'Merchant'),
            const SizedBox(height: 24),
            _buildStatsCards(),
            const SizedBox(height: 24),
            _buildActionsGrid(),
          ],
        ),
      ),
    );
  }

  Widget _buildWelcomeHeader(String merchantName) {
    return Text(
      'Welcome Back,\n$merchantName',
      style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
    );
  }

  Widget _buildStatsCards() {
    return FutureBuilder<Map<String, dynamic>>(
      future: _dashboardDataFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return const Center(child: Text("Could not load stats."));
        }

        final revenue = snapshot.data?['dailyRevenue'] ?? 0.0;
        final newOrders = snapshot.data?['newOrderCount'] ?? 0;

        return Row(
          children: [
            Expanded(child: _buildStatCard("Today's Revenue", '₹${revenue.toStringAsFixed(2)}', Icons.trending_up, Colors.green)),
            const SizedBox(width: 16),
            Expanded(child: _buildStatCard('New Orders', newOrders.toString(), Icons.notifications, Colors.orange)),
          ],
        );
      },
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(height: 8),
            Text(title, style: TextStyle(color: Colors.grey.shade600)),
            const SizedBox(height: 4),
            Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget _buildActionsGrid() {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      children: [
        _buildActionCard('Order Management', Icons.receipt_long, Colors.blue, () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const OrderManagementScreen()));
        }),
        _buildActionCard('Manage Menu', Icons.restaurant_menu, Colors.red, () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const ManageMenuScreen()));
        }),
        _buildActionCard('Top-Up Requests', Icons.monetization_on, Colors.purple, () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const TopUpRequestsScreen()));
        }),
        _buildActionCard('Sales Reports', Icons.bar_chart, Colors.teal, () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const MerchantReportsScreen()));
        }),
      ],
    );
  }

  Widget _buildActionCard(String title, IconData icon, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(15),
      child: Card(
        elevation: 2,
        color: color.withOpacity(0.15),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: color),
            const SizedBox(height: 12),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(fontWeight: FontWeight.bold, color: HSLColor.fromColor(color).withLightness(0.2).toColor()),
            ),
          ],
        ),
      ),
    );
  }
}