import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:food_app/api/api_constants.dart';
import 'package:food_app/models/food_category.dart';
import 'package:food_app/models/menu_item.dart';
import 'package:food_app/providers/cart_provider.dart';
import 'package:food_app/utils/notification_utils.dart';
import 'package:food_app/widgets/app_drawer.dart';
import 'package:food_app/widgets/quantity_toggle.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';
import 'package:lottie/lottie.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  final storage = const FlutterSecureStorage();
  List<MenuItem> _allMenuItems = [];
  List<FoodCategory> _categories = [];
  bool _isLoading = true;
  int? _selectedCategoryId;
  bool _isPlacingOrder = false;
  late AnimationController _cartAnimationController;

  @override
  void initState() {
    super.initState();
    _cartAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
      reverseDuration: const Duration(milliseconds: 300),
    );
    _fetchData();
  }

  @override
  void dispose() {
    _cartAnimationController.dispose();
    super.dispose();
  }

  Future<void> _fetchData() async {
    setState(() => _isLoading = true);
    await Future.wait([_fetchCategories(), _fetchTodaysMenu()]);
    if (mounted) {
      setState(() {
        _isLoading = false;
        if (_categories.isNotEmpty) {
          _selectedCategoryId = _categories.first.id;
        }
      });
    }
  }

  Future<void> _fetchCategories() async {
    try {
      final token = await storage.read(key: 'jwt_token');
      final response = await http.get(
        Uri.parse(ApiConstants.baseUrl + ApiConstants.foodCategories),
        headers: {'Authorization': 'Bearer $token'},
      );
      if (response.statusCode == 200) {
        final List data = jsonDecode(response.body);
        _categories = data.map((json) => FoodCategory.fromJson(json)).toList();
      }
    } catch (e) {
      // Handle error silently in UI
    }
  }

  Future<void> _fetchTodaysMenu() async {
    try {
      final token = await storage.read(key: 'jwt_token');
      final response = await http.get(
        Uri.parse(ApiConstants.baseUrl + ApiConstants.todaysMenu),
        headers: {'Authorization': 'Bearer $token'},
      );
      if (response.statusCode == 200) {
        final List data = jsonDecode(response.body);
        _allMenuItems = data.map((json) => MenuItem.fromJson(json)).toList();
        if(mounted) context.read<CartProvider>().setMenuItems(_allMenuItems);
      }
    } catch (e) {
      // Handle error silently in UI
    }
  }

  List<MenuItem> get _filteredMenuItems {
    if (_selectedCategoryId == null) return [];
    return _allMenuItems.where((item) => item.categoryId == _selectedCategoryId).toList();
  }

  void _showCart(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Consumer<CartProvider>(
          builder: (context, cart, child) {
            return DraggableScrollableSheet(
              expand: false,
              initialChildSize: 0.5,
              maxChildSize: 0.8,
              minChildSize: 0.3,
              builder: (BuildContext context, ScrollController scrollController) {
                return Container(
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                  ),
                  child: Column(
                    children: [
                      Container(
                        width: 40,
                        height: 5,
                        margin: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          color: Colors.grey[300],
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Your Cart', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                            if (cart.cartItems.isNotEmpty)
                              TextButton.icon(
                                onPressed: () => cart.clearCart(),
                                icon: const Icon(Icons.delete_sweep, color: Colors.red),
                                label: const Text('Clear All', style: TextStyle(color: Colors.red)),
                              ),
                          ],
                        ),
                      ),
                      const Divider(),
                      Expanded(
                        child: cart.cartItems.isEmpty
                            ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Lottie.asset('assets/animations/empty_cart.json', width: 150),
                              const SizedBox(height: 16),
                              const Text("Your cart is empty!", style: TextStyle(fontSize: 18, color: Colors.grey)),
                            ],
                          ),
                        )
                            : ListView.builder(
                          controller: scrollController,
                          itemCount: cart.cartItems.length,
                          itemBuilder: (context, index) {
                            final item = cart.cartItems[index];
                            return ListTile(
                              leading: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.network(
                                  ApiConstants.baseUrl + ApiConstants.uploads + item.imagePath,
                                  width: 50, height: 50, fit: BoxFit.cover,
                                  errorBuilder: (ctx, err, st) => const Icon(Icons.fastfood, size: 50),
                                ),
                              ),
                              title: Text(item.name),
                              subtitle: Text('₹${item.price.toStringAsFixed(2)}'),
                              trailing: SizedBox(
                                width: 150,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    QuantityToggle(itemId: item.id),
                                    IconButton(
                                      icon: const Icon(Icons.delete, color: Colors.red),
                                      onPressed: () => cart.clearItemFromCart(item.id),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      const Divider(),
                      Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Total:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                            Text('₹${cart.totalAmount.toStringAsFixed(2)}',
                                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Theme.of(context).primaryColor)),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                        child: SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: cart.cartItems.isEmpty || _isPlacingOrder ? null : () => _placeOrder(context),
                            child: _isPlacingOrder
                                ? const SizedBox(height: 24, width: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                                : const Text('Place Order'),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            );
          },
        );
      },
    );
  }

  Future<void> _placeOrder(BuildContext navContext) async {
    setState(() => _isPlacingOrder = true);
    final cart = Provider.of<CartProvider>(navContext, listen: false);

    final token = await storage.read(key: 'jwt_token');
    final email = await storage.read(key: 'email');

    if (token == null || email == null) {
      NotificationUtils.showAnimatedPopup(context, title: "Error", message: 'Authentication error. Please log in again.', isSuccess: false);
      setState(() => _isPlacingOrder = false);
      return;
    }

    final items = <String, int>{};
    cart.cart.forEach((key, value) {
      items[key.toString()] = value;
    });

    try {
      final response = await http.post(
        Uri.parse(ApiConstants.baseUrl + ApiConstants.placeOrder),
        headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
        body: jsonEncode({'email': email, 'items': items}),
      );

      if (response.statusCode == 200) {
        cart.clearCart();
        Navigator.pop(navContext); // Close bottom sheet
        NotificationUtils.showAnimatedPopup(
          context,
          title: 'Order Placed!',
          message: 'Your order has been sent to the canteen.',
          isSuccess: true,
        );
      } else {
        NotificationUtils.showAnimatedPopup(context, title: "Error", message: 'Failed to place order: ${response.body}', isSuccess: false);
      }
    } catch (e) {
      NotificationUtils.showAnimatedPopup(context, title: "Error", message: 'An error occurred: $e', isSuccess: false);
    } finally {
      if(mounted) setState(() => _isPlacingOrder = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Smart Canteen"),
        actions: [
          ScaleTransition(
            scale: Tween(begin: 1.0, end: 1.2).animate(CurvedAnimation(
              parent: _cartAnimationController,
              curve: Curves.easeOut,
            )),
            child: IconButton(
              icon: const Icon(Icons.shopping_cart_outlined),
              onPressed: () => _showCart(context),
            ),
          ),
        ],
      ),
      drawer: const AppDrawer(),
      body: _isLoading
          ? _buildShimmer()
          : Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildCategorySelector(),
          Expanded(child: _buildMenuGrid()),
        ],
      ),
    );
  }

  Widget _buildCategorySelector() {
    return SizedBox(
      height: 60,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        itemCount: _categories.length,
        itemBuilder: (context, index) {
          final category = _categories[index];
          final isSelected = category.id == _selectedCategoryId;
          return Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: ChoiceChip(
              label: Text(category.name),
              selected: isSelected,
              onSelected: (selected) {
                if (selected) {
                  setState(() => _selectedCategoryId = category.id);
                }
              },
              backgroundColor: Colors.white,
              selectedColor: Theme.of(context).primaryColor,
              labelStyle: TextStyle(
                fontWeight: FontWeight.w600,
                color: isSelected ? Colors.white : Colors.black,
              ),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                  side: BorderSide(color: isSelected ? Theme.of(context).primaryColor : Colors.grey.shade300)
              ),
              showCheckmark: false,
            ),
          );
        },
      ),
    );
  }

  Widget _buildMenuGrid() {
    if (_filteredMenuItems.isEmpty) {
      return const Center(child: Text("No items in this category."));
    }
    return AnimationLimiter(
      child: GridView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _filteredMenuItems.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 0.8,
        ),
        itemBuilder: (context, index) {
          final item = _filteredMenuItems[index];
          return AnimationConfiguration.staggeredGrid(
            position: index,
            duration: const Duration(milliseconds: 375),
            columnCount: 2,
            child: ScaleAnimation(
              child: FadeInAnimation(
                child: Card(
                  elevation: 2,
                  clipBehavior: Clip.antiAlias,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Expanded(
                        child: Image.network(
                          ApiConstants.baseUrl + ApiConstants.uploads + item.imagePath,
                          fit: BoxFit.cover,
                          errorBuilder: (ctx, err, st) => const Center(child: Icon(Icons.fastfood, color: Colors.grey, size: 40)),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(item.name, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      Text('₹${item.price.toStringAsFixed(2)}', textAlign: TextAlign.center),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4),
                        child: GestureDetector(
                            onTap: (){
                              _cartAnimationController.forward().then((_) => _cartAnimationController.reverse());
                            },
                            child: QuantityToggle(itemId: item.id)),
                      )
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildShimmer() {
    return Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: GridView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: 6,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: 0.8,
          ),
          itemBuilder: (context, index) {
            return Card(
              clipBehavior: Clip.antiAlias,
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              child: Container(color: Colors.white),
            );
          }
      ),
    );
  }
}