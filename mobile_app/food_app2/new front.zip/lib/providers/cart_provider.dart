import 'package:flutter/material.dart';
import 'package:food_app/models/menu_item.dart';

class CartProvider with ChangeNotifier {
  final Map<int, int> _cart = {};
  Map<int, MenuItem> _menuItemsMap = {};
  Map<int, int> get cart => _cart;

  void setMenuItems(List<MenuItem> items) {
    _menuItemsMap = {for (var item in items) item.id: item};
  }
  void addToCart(int itemId) {
    _cart.update(itemId, (value) => value + 1, ifAbsent: () => 1);
    notifyListeners();
  }
  void removeFromCart(int itemId) {
    if (_cart.containsKey(itemId) && _cart[itemId]! > 1) {
      _cart[itemId] = _cart[itemId]! - 1;
    } else {
      _cart.remove(itemId);
    }
    notifyListeners();
  }
  void clearItemFromCart(int itemId) { _cart.remove(itemId); notifyListeners(); }
  void clearCart() { _cart.clear(); notifyListeners(); }
  int getQuantity(int itemId) => _cart[itemId] ?? 0;

  double get totalAmount {
    double total = 0.0;
    _cart.forEach((itemId, quantity) {
      final item = _menuItemsMap[itemId];
      if (item != null) total += item.price * quantity;
    });
    return total;
  }

  List<MenuItem> get cartItems {
    return _cart.keys.map((id) => _menuItemsMap[id]).where((item) => item != null).cast<MenuItem>().toList();
  }
}