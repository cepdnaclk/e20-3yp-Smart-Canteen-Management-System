import 'package:flutter/material.dart';
import 'package:food_app/models/order.dart';

class OrderCard extends StatelessWidget {
  final Order order;
  final VoidCallback? onAccept;
  final VoidCallback? onComplete;

  const OrderCard({
    super.key,
    required this.order,
    this.onAccept,
    this.onComplete,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Order #${order.id}',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                Chip(
                  label: Text(order.status),
                  backgroundColor: _getStatusColor(order.status).withOpacity(0.2),
                  labelStyle: TextStyle(color: _getStatusColor(order.status), fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const Divider(height: 20),
            Text('Customer: ${order.customerEmail}'),
            Text('Total: ₹${order.totalAmount.toStringAsFixed(2)}'),
            const SizedBox(height: 12),
            const Text('Items:', style: TextStyle(fontWeight: FontWeight.w500)),
            ...order.items.entries.map((entry) {
              return Text('  • ${entry.key} (x${entry.value})');
            }),
            const SizedBox(height: 12),
            if (onAccept != null || onComplete != null)
              Align(
                alignment: Alignment.centerRight,
                child: ElevatedButton(
                  onPressed: onAccept ?? onComplete,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: onAccept != null ? Colors.green : Colors.blue,
                  ),
                  child: Text(onAccept != null ? 'Accept Order' : 'Mark as Completed'),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toUpperCase()) {
      case 'PENDING':
        return Colors.orange;
      case 'ACCEPTED':
        return Colors.blue;
      case 'COMPLETED':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }
}