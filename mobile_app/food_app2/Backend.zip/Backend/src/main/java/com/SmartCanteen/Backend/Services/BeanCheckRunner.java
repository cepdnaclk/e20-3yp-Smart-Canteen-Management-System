package com.SmartCanteen.Backend.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class BeanCheckRunner implements CommandLineRunner {

    @Autowired
    private ApplicationContext context;

    @Override
    public void run(String... args) throws Exception {
        // Use the bean name: by default, it's the class name with the first letter lowercased
        System.out.println(context.containsBean("orderController")); // true if scanned
    }
}
