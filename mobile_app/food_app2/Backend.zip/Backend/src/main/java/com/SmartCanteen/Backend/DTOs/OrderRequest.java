package com.SmartCanteen.Backend.DTOs;

public class OrderRequest {
    private List<OrderItem> items;
    private String userId;
    // Getters/setters
}
