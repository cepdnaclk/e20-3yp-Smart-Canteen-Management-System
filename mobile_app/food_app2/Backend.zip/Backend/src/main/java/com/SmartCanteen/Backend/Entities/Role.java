package com.SmartCanteen.Backend.Entities;

public enum Role {
    ADMIN,
    CUSTOMER,
    MERCHANT;

}
