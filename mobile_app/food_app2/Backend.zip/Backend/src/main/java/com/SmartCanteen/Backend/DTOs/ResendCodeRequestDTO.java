package com.SmartCanteen.Backend.DTOs;

import lombok.Data;

@Data
public class ResendCodeRequestDTO {
    private String email;
}