package com.SmartCanteen.Backend.Entities;

public enum RequestStatus {
    PENDING,
    APPROVED,
    REJECTED
}
