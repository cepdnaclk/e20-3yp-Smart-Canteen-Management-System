package com.SmartCanteen.Backend.Services;

import com.SmartCanteen.Backend.DTOs.OrderDTO;
import com.SmartCanteen.Backend.Entities.*;
import com.SmartCanteen.Backend.Repositories.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final MenuItemRepository menuItemRepository;
    private final CustomerRepository customerRepository;
    private final NotificationService notificationService;
    // If you use receipts, add: private final ReceiptRepository receiptRepository;

    // Place a new order
    @Transactional
    public OrderDTO placeOrder(OrderDTO orderDTO) {
        if (orderDTO.getEmail() == null) {
            throw new IllegalArgumentException("userEmail must not be null");
        }
        // Add validation in placeOrder()
        if (orderDTO.getItems() == null || orderDTO.getItems().isEmpty()) {
            throw new IllegalArgumentException("Order must contain items");
        }

        Map<String, Integer> itemsMap = orderDTO.getItems(); // Already String keys

        // Calculate total
        BigDecimal total = calculateOrderTotal(itemsMap);

        // Fetch customer
        Customer customer = customerRepository.findByEmail(orderDTO.getEmail())
                .orElseThrow(() -> new RuntimeException("Customer not found: " + orderDTO.getEmail()));

        // Create order
        Order order = new Order();
        order.setCustomer(customer);
        order.setEmail(customer.getEmail());
        order.setStatus(OrderStatus.PENDING);
        order.setOrderTime(orderDTO.getOrderTime() != null ? orderDTO.getOrderTime() : LocalDateTime.now());
        order.setScheduledTime(orderDTO.getScheduledTime());
        order.setItems(itemsMap);
        order.setTotalAmount(total);

        // Save and return
        order = orderRepository.save(order);
        return convertToDTO(order);
    }

    // Calculate total price
    private BigDecimal calculateOrderTotal(Map<String, Integer> items) {
        if (items == null || items.isEmpty()) {
            return BigDecimal.ZERO;
        }
        Set<Long> menuItemIds = items.keySet().stream()
                .map(Long::parseLong)
                .collect(Collectors.toSet());
        Map<Long, MenuItem> menuItemMap = menuItemRepository.findAllById(menuItemIds)
                .stream()
                .collect(Collectors.toMap(MenuItem::getId, mi -> mi));
        BigDecimal total = BigDecimal.ZERO;
        for (var entry : items.entrySet()) {
            Long id = Long.parseLong(entry.getKey());
            MenuItem menuItem = menuItemMap.get(id);
            if (menuItem == null) {
                throw new RuntimeException("MenuItem with ID " + entry.getKey() + " not found");
            }
            total = total.add(menuItem.getPrice().multiply(BigDecimal.valueOf(entry.getValue())));
        }
        return total;
    }

    public List<OrderDTO> getPendingOrders() {
        return orderRepository.findByStatus(OrderStatus.PENDING)
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // Get order history for a customer (by email)
    public List<OrderDTO> getOrderHistory(String email) {
        Customer customer = customerRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Customer not found: " + email));
        return orderRepository.findByCustomer(customer).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // Cancel order (with cancellation fee)
    @Transactional
    public OrderDTO cancelOrder(Long orderId, double cancellationFee) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        if (order.getStatus() == OrderStatus.COMPLETED) {
            throw new RuntimeException("Cannot cancel completed order");
        }

        BigDecimal fee = BigDecimal.valueOf(cancellationFee);
        Customer customer = order.getCustomer();
        customer.setCreditBalance(customer.getCreditBalance().add(order.getTotalAmount().subtract(fee)));
        customerRepository.save(customer);

        order.setStatus(OrderStatus.CANCELLED);
        return convertToDTO(orderRepository.save(order));
    }

    // Update order status (accept, complete, etc.)
    @Transactional
    public OrderDTO updateOrderStatus(Long orderId, String status) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        OrderStatus newStatus = OrderStatus.valueOf(status.toUpperCase());
        order.setStatus(newStatus);

        // If completed, notify user
        if (newStatus == OrderStatus.COMPLETED) {
            notificationService.sendNotification(
                    order.getCustomer(),
                    "Your order #" + orderId + " is ready for pickup!"
            );
        }

        return convertToDTO(orderRepository.save(order));
    }

    // Convert Order entity to DTO
    private OrderDTO convertToDTO(Order order) {
        OrderDTO dto = new OrderDTO();
        dto.setId(order.getId());
        dto.setEmail(order.getEmail());
        dto.setItems(order.getItems()); // Already Map<String, Integer>
        dto.setTotalAmount(order.getTotalAmount());
        dto.setStatus(order.getStatus() != null ? order.getStatus().name() : null);
        dto.setOrderTime(order.getOrderTime());
        dto.setScheduledTime(order.getScheduledTime());
        return dto;
    }
}
