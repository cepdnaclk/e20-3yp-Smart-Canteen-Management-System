package com.SmartCanteen.Backend.Exceptions;

public class VerificationCodeException extends RuntimeException {
    public VerificationCodeException(String message) { super(message); }
}
