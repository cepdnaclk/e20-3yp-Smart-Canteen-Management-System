//package com.SmartCanteen.Backend.Controllers;
//
//import com.SmartCanteen.Backend.DTOs.OrderDTO;
//import com.SmartCanteen.Backend.Entities.Customer;
//import com.SmartCanteen.Backend.Entities.User;
//import com.SmartCanteen.Backend.Repositories.AdminRepository;
//import com.SmartCanteen.Backend.Repositories.CustomerRepository;
//import com.SmartCanteen.Backend.Services.OrderService;
//import lombok.RequiredArgsConstructor;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.core.annotation.AuthenticationPrincipal;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/api/orders")
//@RequiredArgsConstructor
//public class OrderController {
//    private final OrderService orderService;
//    private final CustomerRepository customerRepository;
//    // Place a new order (corrected mapping)
//
//    @PostMapping("/place")
//    public ResponseEntity<OrderDTO> placeOrder(@RequestBody OrderDTO orderDTO) {
//        return ResponseEntity.ok(orderService.placeOrder(orderDTO));
//    }
//
//
//    // Get all orders for a customer
//    @GetMapping("/customer/{userId}")
//    public ResponseEntity<List<OrderDTO>> getCustomerOrders(@PathVariable Long userId) {
//        return ResponseEntity.ok(orderService.getOrderHistory(String.valueOf(userId)));
//    }
//
//    // Cancel an order (with cancellation fee)
//    @PutMapping("/cancel/{orderId}")
//    public ResponseEntity<OrderDTO> cancelOrder(
//            @PathVariable Long orderId,
//            @RequestParam double cancellationFee) {
//        return ResponseEntity.ok(orderService.cancelOrder(orderId, cancellationFee));
//    }
//
//    // Get all pending orders for merchant
//    @GetMapping("/merchant/pending")
//    public ResponseEntity<List<OrderDTO>> getPendingOrders() {
//        return ResponseEntity.ok(orderService.getPendingOrders());
//    }
//
//    // Update order status (e.g., accept, complete, etc.)
//    @PutMapping("/{orderId}/status")
//    public ResponseEntity<OrderDTO> updateOrderStatus(
//            @PathVariable Long orderId,
//            @RequestParam String status) {
//        return ResponseEntity.ok(orderService.updateOrderStatus(orderId, status));
//    }
//
//    @GetMapping("/customer/orders")
//    public ResponseEntity<List<OrderDTO>> getCustomerOrders(@AuthenticationPrincipal User user) {
//        Customer customer = customerRepository.findByEmail(user.getEmail())
//                .orElseThrow(() -> new UsernameNotFoundException("Customer not found"));
//
//        return ResponseEntity.ok(orderService.getOrderHistory(String.valueOf(customer)));
//    }
//
//}

package com.SmartCanteen.Backend.Controllers;

import com.SmartCanteen.Backend.DTOs.OrderDTO;
import com.SmartCanteen.Backend.Entities.Customer;
import com.SmartCanteen.Backend.Entities.User;
import com.SmartCanteen.Backend.Repositories.CustomerRepository;
import com.SmartCanteen.Backend.Services.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {
    private final OrderService orderService;
    private final CustomerRepository customerRepository;

    // Place order (WORKS)
    @PostMapping("/place")
    public ResponseEntity<OrderDTO> placeOrder(@RequestBody OrderDTO orderDTO) {
        return ResponseEntity.ok(orderService.placeOrder(orderDTO));
    }

    // Cancel order (WORKS)
    @PutMapping("/cancel/{orderId}")
    public ResponseEntity<OrderDTO> cancelOrder(
            @PathVariable Long orderId,
            @RequestParam double cancellationFee) {
        return ResponseEntity.ok(orderService.cancelOrder(orderId, cancellationFee));
    }

    // Get pending orders (WORKS)
    @GetMapping("/merchant/pending")
    public ResponseEntity<List<OrderDTO>> getPendingOrders() {
        return ResponseEntity.ok(orderService.getPendingOrders());
    }

    // Update status (WORKS)
    @PutMapping("/{orderId}/status")
    public ResponseEntity<OrderDTO> updateOrderStatus(
            @PathVariable Long orderId,
            @RequestParam String status) {
        return ResponseEntity.ok(orderService.updateOrderStatus(orderId, status));
    }

    // Get orders for logged-in user (FIXED)
    @GetMapping("/my-orders")
    public ResponseEntity<List<OrderDTO>> getMyOrders(
            @AuthenticationPrincipal User user) {
        Customer customer = customerRepository.findByEmail(user.getEmail())
                .orElseThrow(() -> new UsernameNotFoundException("Customer not found"));
        return ResponseEntity.ok(orderService.getOrderHistory(customer.getEmail()));
    }
}



