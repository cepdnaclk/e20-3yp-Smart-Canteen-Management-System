import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';

// --- Order Model ---
class Order {
  final String id;
  final String email;
  final DateTime orderTime;
  final DateTime? scheduledTime;
  final Map<String, dynamic> items;
  final double totalAmount;
  final String status;

  Order({
    required this.id,
    required this.email,
    required this.orderTime,
    this.scheduledTime,
    required this.items,
    required this.totalAmount,
    required this.status,
  });

  factory Order.fromJson(Map<String, dynamic> json) {
    return Order(
      id: json['id'].toString(),
      email: json['email'] ?? 'Unknown',
      orderTime: DateTime.parse(json['orderTime']),
      scheduledTime: json['scheduledTime'] != null
          ? DateTime.parse(json['scheduledTime'])
          : null,
      items: Map<String, dynamic>.from(json['items']),
      totalAmount: (json['totalAmount'] as num).toDouble(),
      status: json['status'],
    );
  }
}

// --- Order Service ---
class OrderService {
  static const String baseUrl = 'http://192.168.56.1:8081/api/orders';

  Future<List<Order>> fetchCompletedOrders() async {
    final response = await http.get(
      Uri.parse('$baseUrl/merchant/completed'),
      headers: {'Content-Type': 'application/json'},
    );
    if (response.statusCode == 200) {
      List<dynamic> data = json.decode(response.body);
      return data.map((json) => Order.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load completed orders: ${response.statusCode}');
    }
  }
}

// --- Completed Orders Screen ---
class CompletedOrdersScreen extends StatefulWidget {
  const CompletedOrdersScreen({super.key});

  @override
  _CompletedOrdersScreenState createState() => _CompletedOrdersScreenState();
}

class _CompletedOrdersScreenState extends State<CompletedOrdersScreen> {
  final OrderService _orderService = OrderService();
  late Future<List<Order>> _completedOrders;

  @override
  void initState() {
    super.initState();
    _refreshCompletedOrders();
  }

  void _refreshCompletedOrders() {
    setState(() {
      _completedOrders = _orderService.fetchCompletedOrders();
    });
  }

  Map<String, List<Order>> _groupOrdersByDate(List<Order> orders) {
    Map<String, List<Order>> groupedOrders = {};
    final dateFormat = DateFormat('yyyy-MM-dd');
    for (var order in orders) {
      String dateKey = dateFormat.format(order.orderTime.toLocal());
      groupedOrders.putIfAbsent(dateKey, () => []).add(order);
    }
    return groupedOrders;
  }

  double _calculateDailyTotal(List<Order> orders) {
    return orders.fold(0.0, (sum, order) => sum + order.totalAmount);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Completed Orders'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refreshCompletedOrders,
          ),
        ],
      ),
      body: FutureBuilder<List<Order>>(
        future: _completedOrders,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          final orders = snapshot.data!;
          if (orders.isEmpty) {
            return const Center(child: Text('No completed orders'));
          }

          final groupedOrders = _groupOrdersByDate(orders);
          final sortedDates = groupedOrders.keys.toList()
            ..sort((a, b) => b.compareTo(a)); // Sort by date descending

          return ListView.builder(
            itemCount: sortedDates.length,
            itemBuilder: (context, index) {
              final date = sortedDates[index];
              final dailyOrders = groupedOrders[date]!;
              final dailyTotal = _calculateDailyTotal(dailyOrders);

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                child: ExpansionTile(
                  title: Text(
                    DateFormat('MMMM dd, yyyy').format(DateTime.parse(date)),
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text('Total Income: ₹${dailyTotal.toStringAsFixed(2)}'),
                  children: dailyOrders.map((order) {
                    return ListTile(
                      title: Text('Order #${order.id}'),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Time: ${DateFormat('HH:mm').format(order.orderTime.toLocal())}'),
                          Text('Items: ${order.items.entries.map((e) => "${e.key} x${e.value}").join(", ")}'),
                          Text('Price: ₹${order.totalAmount.toStringAsFixed(2)}'),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              );
            },
          );
        },
      ),
    );
  }
}