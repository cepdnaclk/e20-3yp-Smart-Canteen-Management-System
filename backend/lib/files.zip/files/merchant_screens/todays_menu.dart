import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// --- Models ---
class FoodItem {
  final int id;
  final String name;
  final String? imagePath;
  final double price;
  final int stock;
  final int categoryId;
  final String? categoryName;
  final bool isInTodayMenu;

  FoodItem({
    required this.id,
    required this.name,
    this.imagePath,
    required this.price,
    required this.stock,
    required this.categoryId,
    this.categoryName,
    required this.isInTodayMenu,
  });

  factory FoodItem.fromJson(Map<String, dynamic> json) {
    return FoodItem(
      id: json['id'] is int ? json['id'] : int.parse(json['id'].toString()),
      name: json['name'] ?? '',
      imagePath: json['imagePath'],
      price: json['price'] is double
          ? json['price']
          : (json['price'] is int
          ? (json['price'] as int).toDouble()
          : double.parse(json['price'].toString())),
      stock: json['stock'] ?? 0,
      categoryId: json['categoryId'] is int
          ? json['categoryId']
          : int.parse(json['categoryId'].toString()),
      categoryName: json['categoryName'],
      isInTodayMenu: json['isInTodayMenu'] ?? false,
    );
  }
}

class FoodCategory {
  final int id;
  final String name;
  final List<FoodItem> items;

  FoodCategory({
    required this.id,
    required this.name,
    required this.items,
  });
}

// --- API Service ---
class ApiService {
  static const String baseUrl = 'http://192.168.56.1:8081/api';
  static const String uploadUrl = 'http://192.168.56.1:8081/api/uploads/';

  static Future<List<FoodCategory>> fetchCategoriesWithFoods() async {
    final response = await http.get(Uri.parse('$baseUrl/food-categories/with-today-menu'));
    if (response.statusCode == 200) {
      List<dynamic> cats = jsonDecode(response.body);
      return cats.map((cat) {
        List<FoodItem> items = [];
        if (cat['menuItems'] != null) {
          items = (cat['menuItems'] as List)
              .map((item) => FoodItem.fromJson(item))
              .toList();
        }
        return FoodCategory(
          id: cat['id'] is int ? cat['id'] : int.parse(cat['id'].toString()),
          name: cat['name'],
          items: items,
        );
      }).toList();
    }
    throw Exception('Failed to fetch categories');
  }

  static Future<void> updateTodaysMenu(List<int> foodIds) async {
    final response = await http.post(
      Uri.parse('$baseUrl/menu/today'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'foodIds': foodIds}),
    );
    if (response.statusCode != 200 && response.statusCode != 204) {
      throw Exception('Failed to update today\'s menu');
    }
  }
}

// --- Merchant Menu Selection Page ---
class MerchantMenuSelectionPage extends StatefulWidget {
  const MerchantMenuSelectionPage({super.key});

  @override
  State<MerchantMenuSelectionPage> createState() => _MerchantMenuSelectionPageState();
}

class _MerchantMenuSelectionPageState extends State<MerchantMenuSelectionPage> {
  List<FoodCategory> categories = [];
  Set<int> selectedFoodIds = {};
  bool isLoading = true;
  bool isSaving = false;

  @override
  void initState() {
    super.initState();
    _fetchCategories();
  }

  Future<void> _fetchCategories() async {
    setState(() => isLoading = true);
    try {
      categories = await ApiService.fetchCategoriesWithFoods();
      // Always re-initialize selectedFoodIds from backend data
      selectedFoodIds = Set.from(categories
          .expand((cat) => cat.items)
          .where((item) => item.isInTodayMenu)
          .map((item) => item.id));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load foods: $e'), backgroundColor: Colors.red),
      );
    }
    setState(() => isLoading = false);
  }

  void _toggleFood(int foodId) {
    setState(() {
      if (selectedFoodIds.contains(foodId)) {
        selectedFoodIds.remove(foodId);
      } else {
        selectedFoodIds.add(foodId);
      }
    });
  }

  Future<void> _saveMenu() async {
    setState(() => isSaving = true);
    try {
      await ApiService.updateTodaysMenu(selectedFoodIds.toList());
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Today\'s menu updated!'), backgroundColor: Colors.green),
      );
      await _fetchCategories(); // <-- Refresh after save!
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to update menu: $e'), backgroundColor: Colors.red),
      );
    }
    setState(() => isSaving = false);
  }

  Widget _buildSelectedItems() {
    final selectedItems = categories
        .expand((cat) => cat.items)
        .where((item) => selectedFoodIds.contains(item.id))
        .toList();

    if (selectedItems.isEmpty) {
      return const SizedBox.shrink();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.all(16.0),
          child: Text('Selected Items for Today\'s Menu:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ),
        SizedBox(
          height: 120,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: selectedItems.length,
            itemBuilder: (context, index) {
              final item = selectedItems[index];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (item.imagePath != null && item.imagePath!.isNotEmpty)
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            '${ApiService.uploadUrl}${item.imagePath}',
                            width: 60,
                            height: 60,
                            fit: BoxFit.cover,
                          ),
                        )
                      else
                        const Icon(Icons.fastfood, size: 40),
                      const SizedBox(width: 8),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item.name,
                              style: const TextStyle(fontWeight: FontWeight.w500)),
                          Text('₹${item.price.toStringAsFixed(2)}'),
                        ],
                      ),
                      IconButton(
                        icon: const Icon(Icons.remove_circle, color: Colors.red),
                        onPressed: () => _toggleFood(item.id),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        const Divider(thickness: 2),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Select Today\'s Menu'),
        actions: [
          IconButton(
            icon: isSaving
                ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.save),
            onPressed: isSaving ? null : _saveMenu,
            tooltip: 'Save Today\'s Menu',
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
        children: [
          _buildSelectedItems(),
          Expanded(
            child: RefreshIndicator(
              onRefresh: _fetchCategories,
              child: ListView(
                children: categories.map((cat) {
                  return ExpansionTile(
                    title: Text(cat.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                    children: cat.items.map((food) {
                      return CheckboxListTile(
                        value: selectedFoodIds.contains(food.id),
                        onChanged: (_) => _toggleFood(food.id),
                        title: Row(
                          children: [
                            if (food.imagePath != null && food.imagePath!.isNotEmpty)
                              ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.network(
                                  '${ApiService.uploadUrl}${food.imagePath}',
                                  width: 50,
                                  height: 50,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => const Icon(Icons.fastfood),
                                ),
                              )
                            else
                              const Icon(Icons.fastfood, size: 40),
                            const SizedBox(width: 12),
                            Expanded(child: Text(food.name)),
                            Text('₹${food.price.toStringAsFixed(2)}',
                                style: const TextStyle(fontWeight: FontWeight.w500)),
                          ],
                        ),
                        subtitle: Text('Stock: ${food.stock}'),
                        controlAffinity: ListTileControlAffinity.leading,
                      );
                    }).toList(),
                  );
                }).toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
