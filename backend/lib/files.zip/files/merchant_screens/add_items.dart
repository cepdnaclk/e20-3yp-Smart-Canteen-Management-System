// import 'dart:io';
// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:http/http.dart' as http;
// import 'dart:convert';
//
// void main() => runApp(const MyApp());
//
// class MyApp extends StatelessWidget {
//   const MyApp({super.key});
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Smart Canteen - Food Manager',
//       theme: ThemeData(primarySwatch: Colors.teal, useMaterial3: true),
//       home: const FoodManagementScreen(),
//       debugShowCheckedModeBanner: false,
//     );
//   }
// }
//
// class FoodItem {
//   final String id;
//   String name;
//   String? imagePath;
//   double price;
//   int stock;
//   int categoryId;
//   String? categoryName;
//
//   FoodItem({
//     required this.id,
//     required this.name,
//     this.imagePath,
//     required this.price,
//     required this.stock,
//     required this.categoryId,
//     this.categoryName,
//   });
//
//   factory FoodItem.fromJson(Map<String, dynamic> json) {
//     return FoodItem(
//       id: json['id'].toString(),
//       name: json['name'] ?? '',
//       imagePath: json['imagePath'],
//       price: json['price'] is double
//           ? json['price']
//           : (json['price'] is int
//           ? (json['price'] as int).toDouble()
//           : double.parse(json['price'].toString())),
//       stock: json['stock'] ?? 0,
//       categoryId: json['categoryId'] is int
//           ? json['categoryId']
//           : int.parse(json['categoryId'].toString()),
//       categoryName: json['categoryName'],
//     );
//   }
//
//   Map<String, dynamic> toJson() {
//     return {
//       'id': id,
//       'name': name,
//       'imagePath': imagePath,
//       'price': price,
//       'stock': stock,
//       'categoryId': categoryId,
//     };
//   }
// }
//
// class ApiService {
//   static const String baseUrl = 'http://192.168.56.1:8081/api/menu-items';
//   static const String uploadUrl = 'http://192.168.56.1:8081/api/uploads/';
//   static const String categoryUrl = 'http://192.168.56.1:8081/api/food-categories';
//   static const Map<String, String> headers = {
//     'Content-Type': 'application/json',
//     'Accept': 'application/json',
//   };
//
//   static Future<List<FoodItem>> getFoodItems() async {
//     final response = await http.get(Uri.parse(baseUrl), headers: headers);
//     if (response.statusCode == 200) {
//       List<dynamic> body = jsonDecode(response.body);
//       return body.map((item) => FoodItem.fromJson(item)).toList();
//     } else {
//       throw Exception('Failed to load food items');
//     }
//   }
//
//   static Future<List<Map<String, dynamic>>> getCategories() async {
//     final response = await http.get(Uri.parse(categoryUrl), headers: headers);
//     if (response.statusCode == 200) {
//       return List<Map<String, dynamic>>.from(jsonDecode(response.body));
//     }
//     throw Exception('Failed to load categories');
//   }
//
//   static Future<Map<String, dynamic>> addCategory(String name) async {
//     final response = await http.post(
//       Uri.parse(categoryUrl),
//       headers: headers,
//       body: jsonEncode({'name': name , 'description':"${name} is added"}),
//     );
//     if (response.statusCode == 201 || response.statusCode == 200) {
//       return jsonDecode(response.body);
//     }
//     throw Exception('Failed to add category');
//   }
//
//   static Future<void> deleteCategory(int id) async {
//     final response = await http.delete(
//       Uri.parse('$categoryUrl/$id'),
//       headers: headers,
//     );
//     if (response.statusCode != 204) {
//       throw Exception('Failed to delete category');
//     }
//   }
//
//   // In ApiService.dart
//   static Future<String> uploadImage(XFile image) async {
//     final request = http.MultipartRequest('POST', Uri.parse(uploadUrl));
//
//     if (kIsWeb) {
//       // On web, use bytes
//       final bytes = await image.readAsBytes();
//       request.files.add(
//         http.MultipartFile.fromBytes(
//           'file',
//           bytes,
//           filename: image.name,
//         ),
//       );
//     } else {
//       // On mobile/desktop, use file path
//       request.files.add(
//         await http.MultipartFile.fromPath(
//           'file',
//           image.path,
//           filename: image.name,
//         ),
//       );
//     }
//
//     final response = await request.send();
//     if (response.statusCode == 200) {
//       return jsonDecode(await response.stream.bytesToString())['filePath'];
//     }
//     throw Exception('Image upload failed');
//   }
//
//
//   static Future<FoodItem> addFoodItem(FoodItem item, XFile? image) async {
//     String? imagePath;
//     if (image != null) {
//       imagePath = await uploadImage(image);
//     }
//     final response = await http.post(
//       Uri.parse(baseUrl),
//       headers: headers,
//       body: jsonEncode({
//         'name': item.name,
//         'price': item.price,
//         'stock': item.stock,
//         'categoryId': item.categoryId,
//         'imagePath': imagePath,
//       }),
//     );
//     if (response.statusCode == 201 || response.statusCode == 200) {
//       return FoodItem.fromJson(jsonDecode(response.body));
//     }
//     throw Exception('Failed to add food item');
//   }
//
//   static Future<FoodItem> updateFoodItem(FoodItem item, XFile? image) async {
//     String? imagePath = item.imagePath;
//     if (image != null) {
//       imagePath = await uploadImage(image);
//     }
//     final response = await http.put(
//       Uri.parse('$baseUrl/${item.id}'),
//       headers: headers,
//       body: jsonEncode({
//         'name': item.name,
//         'price': item.price,
//         'stock': item.stock,
//         'categoryId': item.categoryId,
//         'imagePath': imagePath,
//       }),
//     );
//     if (response.statusCode == 200) {
//       return FoodItem.fromJson(jsonDecode(response.body));
//     }
//     throw Exception('Failed to update food item');
//   }
//
//   static Future<void> deleteFoodItem(String id) async {
//     final response = await http.delete(
//       Uri.parse('$baseUrl/$id'),
//       headers: headers,
//     );
//     if (response.statusCode != 204) {
//       throw Exception('Failed to delete food item');
//     }
//   }
// }
//
// class FoodManagementScreen extends StatefulWidget {
//   const FoodManagementScreen({super.key});
//
//   @override
//   State<FoodManagementScreen> createState() => _FoodManagementScreenState();
// }
//
// class _FoodManagementScreenState extends State<FoodManagementScreen>
//     with SingleTickerProviderStateMixin {
//   List<Map<String, dynamic>> categories = [];
//   List<FoodItem> foodItems = [];
//   bool isLoading = true;
//   TabController? _tabController;
//   final ImagePicker _picker = ImagePicker();
//   XFile? _selectedImage;
//
//   @override
//   void initState() {
//     super.initState();
//     _loadCategories().then((_) {
//       _updateTabController();
//       _loadFoodItems();
//     });
//   }
//
//   @override
//   void dispose() {
//     _tabController?.dispose();
//     super.dispose();
//   }
//
//   Future<void> _loadCategories() async {
//     try {
//       final fetchedCategories = await ApiService.getCategories();
//       setState(() {
//         categories = fetchedCategories;
//       });
//     } catch (e) {
//       _showErrorSnackbar('Failed to load categories: $e');
//       setState(() {
//         categories = [];
//       });
//     }
//   }
//
//   Future<void> _loadFoodItems() async {
//     setState(() => isLoading = true);
//     try {
//       final items = await ApiService.getFoodItems();
//       setState(() => foodItems = items);
//     } catch (e) {
//       _showErrorSnackbar('Failed to load food items: $e');
//     } finally {
//       setState(() => isLoading = false);
//     }
//   }
//
//   void _updateTabController() {
//     _tabController?.dispose();
//     _tabController = TabController(
//       length: categories.length,
//       vsync: this,
//     );
//     setState(() {});
//   }
//
//   Future<void> _pickImage(bool fromCamera) async {
//     try {
//       final XFile? picked = await _picker.pickImage(
//         source: fromCamera ? ImageSource.camera : ImageSource.gallery,
//         imageQuality: 75,
//       );
//       if (picked != null) {
//         setState(() => _selectedImage = picked);
//       }
//     } catch (e) {
//       _showErrorSnackbar('Failed to pick image: $e');
//     }
//   }
//
//   void _showErrorSnackbar(String message) {
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(content: Text(message), backgroundColor: Colors.red),
//     );
//   }
//
//   void _showSuccessSnackbar(String message) {
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(content: Text(message), backgroundColor: Colors.green),
//     );
//   }
//
//   Future<void> _showAddCategoryDialog() async {
//     final nameController = TextEditingController();
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('Add New Category'),
//         content: TextField(
//           controller: nameController,
//           decoration: const InputDecoration(labelText: 'Category Name'),
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context),
//             child: const Text('Cancel'),
//           ),
//           ElevatedButton(
//             onPressed: () async {
//               if (nameController.text.trim().isNotEmpty) {
//                 try {
//                   final newCategory = await ApiService.addCategory(nameController.text.trim());
//                   setState(() {
//                     categories.add({'id': newCategory['id'] as int, 'name': newCategory['name'] as String});
//                     _updateTabController();
//                   });
//                   _showSuccessSnackbar('Category added successfully');
//                   Navigator.pop(context);
//                 } catch (e) {
//                   _showErrorSnackbar('Failed to add category: $e');
//                 }
//               } else {
//                 _showErrorSnackbar('Category name is required');
//               }
//             },
//             child: const Text('Confirm'),
//           ),
//         ],
//       ),
//     );
//   }
//
//   Future<void> _showDeleteCategoriesDialog() async {
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('Delete Categories'),
//         content: SizedBox(
//           width: double.maxFinite,
//           child: ListView.builder(
//             shrinkWrap: true,
//             itemCount: categories.length,
//             itemBuilder: (context, index) {
//               final category = categories[index];
//               return ListTile(
//                 title: Text(category['name']),
//                 trailing: IconButton(
//                   icon: const Icon(Icons.delete, color: Colors.red),
//                   onPressed: () async {
//                     try {
//                       await ApiService.deleteCategory(category['id']);
//                       setState(() {
//                         categories.removeAt(index);
//                         _updateTabController();
//                       });
//                       _showSuccessSnackbar('Category deleted');
//                       Navigator.pop(context);
//                     } catch (e) {
//                       _showErrorSnackbar('Failed to delete category: $e');
//                     }
//                   },
//                 ),
//               );
//             },
//           ),
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context),
//             child: const Text('Close'),
//           ),
//         ],
//       ),
//     );
//   }
//
//   Future<void> _showFoodDialog({FoodItem? item, required int categoryId}) async {
//     final nameController = TextEditingController(text: item?.name ?? '');
//     final priceController = TextEditingController(text: item?.price.toString() ?? '');
//     final stockController = TextEditingController(text: item?.stock.toString() ?? '');
//     XFile? pickedImage = _selectedImage;
//
//     await showDialog(
//       context: context,
//       builder: (context) => StatefulBuilder(
//         builder: (context, setStateDialog) => AlertDialog(
//           title: Text(item == null ? 'Add Food' : 'Edit Food'),
//           content: SingleChildScrollView(
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 GestureDetector(
//                   onTap: () async {
//                     final picked = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 75);
//                     if (picked != null) {
//                       setStateDialog(() => pickedImage = picked);
//                     }
//                   },
//                   child: pickedImage != null || (item?.imagePath?.isNotEmpty ?? false)
//                       ? Image.file(
//                     File(pickedImage?.path ?? ''),
//                     width: 80,
//                     height: 80,
//                     fit: BoxFit.cover,
//                   )
//                       : Container(
//                     width: 80,
//                     height: 80,
//                     color: Colors.grey[300],
//                     child: const Icon(Icons.camera_alt, size: 40),
//                   ),
//                 ),
//                 TextField(
//                   controller: nameController,
//                   decoration: const InputDecoration(labelText: 'Name'),
//                 ),
//                 TextField(
//                   controller: priceController,
//                   decoration: const InputDecoration(labelText: 'Price'),
//                   keyboardType: TextInputType.number,
//                 ),
//                 TextField(
//                   controller: stockController,
//                   decoration: const InputDecoration(labelText: 'Stock'),
//                   keyboardType: TextInputType.number,
//                 ),
//               ],
//             ),
//           ),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.pop(context),
//               child: const Text('Cancel'),
//             ),
//             ElevatedButton(
//               onPressed: () async {
//                 final name = nameController.text.trim();
//                 final price = double.tryParse(priceController.text.trim()) ?? 0.0;
//                 final stock = int.tryParse(stockController.text.trim()) ?? 0;
//
//                 if (name.isEmpty || price <= 0 || stock < 0) {
//                   _showErrorSnackbar('Please fill all fields correctly');
//                   return;
//                 }
//
//                 try {
//                   if (item == null) {
//                     final newItem = FoodItem(
//                       id: '',
//                       name: name,
//                       price: price,
//                       stock: stock,
//                       categoryId: categoryId,
//                     );
//                     final added = await ApiService.addFoodItem(newItem, pickedImage);
//                     setState(() {
//                       foodItems.add(added);
//                     });
//                     _showSuccessSnackbar('Food item added');
//                   } else {
//                     item.name = name;
//                     item.price = price;
//                     item.stock = stock;
//                     final updated = await ApiService.updateFoodItem(item, pickedImage);
//                     setState(() {
//                       final idx = foodItems.indexWhere((f) => f.id == item.id);
//                       if (idx != -1) foodItems[idx] = updated;
//                     });
//                     _showSuccessSnackbar('Food item updated');
//                   }
//                   Navigator.pop(context);
//                 } catch (e) {
//                   _showErrorSnackbar('Failed to save food item: $e');
//                 }
//               },
//               child: const Text('Save'),
//             ),
//           ],
//         ),
//       ),
//     );
//     _selectedImage = null;
//   }
//
//   Future<void> _deleteFood(FoodItem item) async {
//     if (item.id.isEmpty) {
//       _showErrorSnackbar('Cannot delete item: Invalid ID');
//       return;
//     }
//     try {
//       await ApiService.deleteFoodItem(item.id);
//       setState(() {
//         foodItems.removeWhere((f) => f.id == item.id);
//       });
//       _showSuccessSnackbar('Food item deleted successfully');
//     } catch (e) {
//       _showErrorSnackbar('Failed to delete food item: $e');
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Smart Canteen - Food Manager'),
//         actions: [
//           PopupMenuButton<int>(
//             icon: const Icon(Icons.more_vert),
//             onSelected: (value) {
//               if (value == 0) {
//                 _showAddCategoryDialog();
//               } else if (value == 1) {
//                 _showDeleteCategoriesDialog();
//               }
//             },
//             itemBuilder: (context) => [
//               const PopupMenuItem(
//                 value: 0,
//                 child: Text('Add New Category'),
//               ),
//               const PopupMenuItem(
//                 value: 1,
//                 child: Text('Delete Categories'),
//                 enabled: true,
//               ),
//             ],
//           ),
//         ],
//         bottom: categories.isEmpty || _tabController == null
//             ? null
//             : TabBar(
//           controller: _tabController,
//           tabs: categories.map((c) => Tab(text: c['name'])).toList(),
//           isScrollable: true,
//         ),
//       ),
//       body: isLoading || categories.isEmpty || _tabController == null
//           ? const Center(child: CircularProgressIndicator())
//           : TabBarView(
//         controller: _tabController,
//         children: categories.map((category) {
//           final filteredItems = foodItems.where((f) => f.categoryId == category['id']).toList();
//           return Column(
//             children: [
//               Expanded(
//                 child: filteredItems.isEmpty
//                     ? const Center(child: Text('No items yet'))
//                     : RefreshIndicator(
//                   onRefresh: _loadFoodItems,
//                   child: ListView.builder(
//                     itemCount: filteredItems.length,
//                     itemBuilder: (context, index) {
//                       final item = filteredItems[index];
//                       final imageWidget = item.imagePath != null && item.imagePath!.isNotEmpty
//                           ? Image.network(
//                         '${ApiService.uploadUrl}${item.imagePath}',
//                         width: 50,
//                         height: 50,
//                         fit: BoxFit.cover,
//                         errorBuilder: (_, __, ___) => const Icon(Icons.fastfood),
//                       )
//                           : const Icon(Icons.fastfood);
//
//                       return Card(
//                         margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//                         child: ListTile(
//                           leading: ClipRRect(
//                             borderRadius: BorderRadius.circular(6),
//                             child: imageWidget,
//                           ),
//                           title: Text(item.name),
//                           subtitle: Column(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               Text('Rs. ${item.price.toStringAsFixed(2)}'),
//                               Text('Stock: ${item.stock}'),
//                             ],
//                           ),
//                           trailing: Row(
//                             mainAxisSize: MainAxisSize.min,
//                             children: [
//                               IconButton(
//                                 icon: const Icon(Icons.edit),
//                                 onPressed: () => _showFoodDialog(
//                                   item: item,
//                                   categoryId: item.categoryId,
//                                 ),
//                               ),
//                               IconButton(
//                                 icon: const Icon(Icons.delete),
//                                 onPressed: () => _deleteFood(item),
//                               ),
//                             ],
//                           ),
//                         ),
//                       );
//                     },
//                   ),
//                 ),
//               ),
//             ],
//           );
//         }).toList(),
//       ),
//       floatingActionButton: categories.isEmpty || _tabController == null
//           ? null
//           : Builder(
//         builder: (context) {
//           final currentIndex = _tabController!.index;
//           final currentCategory = categories[currentIndex];
//           return FloatingActionButton.extended(
//             onPressed: () => _showFoodDialog(categoryId: currentCategory['id']),
//             label: const Text('Add Food'),
//             icon: const Icon(Icons.fastfood),
//           );
//         },
//       ),
//     );
//   }
// }
//

import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Canteen - Food Manager',
      theme: ThemeData(primarySwatch: Colors.teal, useMaterial3: true),
      home: const FoodManagementScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class FoodItem {
  final String id;
  String name;
  String? imagePath;
  double price;
  int stock;
  int categoryId;
  String? categoryName;

  FoodItem({
    required this.id,
    required this.name,
    this.imagePath,
    required this.price,
    required this.stock,
    required this.categoryId,
    this.categoryName,
  });

  factory FoodItem.fromJson(Map<String, dynamic> json) {
    return FoodItem(
      id: json['id'].toString(),
      name: json['name'] ?? '',
      imagePath: json['imagePath'],
      price: json['price'] is double
          ? json['price']
          : (json['price'] is int
          ? (json['price'] as int).toDouble()
          : double.parse(json['price'].toString())),
      stock: json['stock'] ?? 0,
      categoryId: json['categoryId'] is int
          ? json['categoryId']
          : int.parse(json['categoryId'].toString()),
      categoryName: json['categoryName'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'imagePath': imagePath,
      'price': price,
      'stock': stock,
      'categoryId': categoryId,
    };
  }
}

class ApiService {
  static const String baseUrl = 'http://192.168.56.1:8081/api/menu-items';
  static const String uploadUrl = 'http://192.168.56.1:8081/api/uploads/';
  static const String categoryUrl = 'http://192.168.56.1:8081/api/food-categories';
  static const Map<String, String> headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  };

  static Future<List<FoodItem>> getFoodItems() async {
    final response = await http.get(Uri.parse(baseUrl), headers: headers);
    if (response.statusCode == 200) {
      List<dynamic> body = jsonDecode(response.body);
      return body.map((item) => FoodItem.fromJson(item)).toList();
    } else {
      throw Exception('Failed to load food items');
    }
  }

  static Future<List<Map<String, dynamic>>> getCategories() async {
    final response = await http.get(Uri.parse(categoryUrl), headers: headers);
    if (response.statusCode == 200) {
      var cats = List<Map<String, dynamic>>.from(jsonDecode(response.body));
      cats.sort((a, b) => (a['id'] as int).compareTo(b['id'] as int));
      return cats;
    }
    throw Exception('Failed to load categories');
  }

  static Future<Map<String, dynamic>> addCategory(String name) async {
    final response = await http.post(
      Uri.parse(categoryUrl),
      headers: headers,
      body: jsonEncode({'name': name, 'description': "$name is added"}),
    );
    if (response.statusCode == 201 || response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    throw Exception('Failed to add category');
  }

  static Future<void> deleteCategory(int id) async {
    final response = await http.delete(
      Uri.parse('$categoryUrl/$id'),
      headers: headers,
    );
    if (response.statusCode != 204) {
      throw Exception('Failed to delete category');
    }
  }

  static Future<String> uploadImage(XFile image) async {
    final request = http.MultipartRequest('POST', Uri.parse(uploadUrl));
    if (kIsWeb) {
      final bytes = await image.readAsBytes();
      request.files.add(
        http.MultipartFile.fromBytes(
          'file',
          bytes,
          filename: image.name,
        ),
      );
    } else {
      request.files.add(
        await http.MultipartFile.fromPath(
          'file',
          image.path,
          filename: image.name,
        ),
      );
    }
    final response = await request.send();
    if (response.statusCode == 200) {
      return jsonDecode(await response.stream.bytesToString())['filePath'];
    }
    throw Exception('Image upload failed');
  }

  static Future<FoodItem> addFoodItem(FoodItem item, XFile? image) async {
    String? imagePath;
    if (image != null) {
      imagePath = await uploadImage(image);
    }
    final response = await http.post(
      Uri.parse(baseUrl),
      headers: headers,
      body: jsonEncode({
        'name': item.name,
        'price': item.price,
        'stock': item.stock,
        'categoryId': item.categoryId,
        'imagePath': imagePath,
      }),
    );
    if (response.statusCode == 201 || response.statusCode == 200) {
      return FoodItem.fromJson(jsonDecode(response.body));
    }
    throw Exception('Failed to add food item');
  }

  static Future<FoodItem> updateFoodItem(FoodItem item, XFile? image) async {
    String? imagePath = item.imagePath;
    if (image != null) {
      imagePath = await uploadImage(image);
    }
    final response = await http.put(
      Uri.parse('$baseUrl/${item.id}'),
      headers: headers,
      body: jsonEncode({
        'name': item.name,
        'price': item.price,
        'stock': item.stock,
        'categoryId': item.categoryId,
        'imagePath': imagePath,
      }),
    );
    if (response.statusCode == 200) {
      return FoodItem.fromJson(jsonDecode(response.body));
    }
    throw Exception('Failed to update food item');
  }

  static Future<void> deleteFoodItem(String id) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/$id'),
      headers: headers,
    );
    if (response.statusCode != 204) {
      throw Exception('Failed to delete food item');
    }
  }
}

class FoodManagementScreen extends StatefulWidget {
  const FoodManagementScreen({super.key});

  @override
  State<FoodManagementScreen> createState() => _FoodManagementScreenState();
}

class _FoodManagementScreenState extends State<FoodManagementScreen>
    with SingleTickerProviderStateMixin {
  List<Map<String, dynamic>> categories = [];
  List<FoodItem> foodItems = [];
  bool isLoading = true;
  TabController? _tabController;
  final ImagePicker _picker = ImagePicker();
  XFile? _selectedImage;

  int _currentTabIndex = 0;

  @override
  void initState() {
    super.initState();
    _loadCategories().then((_) {
      _updateTabController();
      _loadFoodItems();
    });
  }

  @override
  void dispose() {
    _tabController?.dispose();
    super.dispose();
  }

  Future<void> _loadCategories() async {
    try {
      final fetchedCategories = await ApiService.getCategories();
      setState(() {
        categories = fetchedCategories;
      });
      _updateTabController();
    } catch (e) {
      _showErrorSnackbar('Failed to load categories: $e');
      setState(() {
        categories = [];
      });
    }
  }

  Future<void> _loadFoodItems() async {
    setState(() => isLoading = true);
    try {
      final items = await ApiService.getFoodItems();
      setState(() => foodItems = items);
    } catch (e) {
      _showErrorSnackbar('Failed to load food items: $e');
    } finally {
      setState(() => isLoading = false);
    }
  }

  void _updateTabController({int? initialIndex}) {
    final oldIndex = _tabController?.index ?? 0;
    _tabController?.removeListener(_handleTabChange);
    _tabController?.dispose();
    _tabController = TabController(
      length: categories.length,
      vsync: this,
      initialIndex: initialIndex ?? (oldIndex < categories.length ? oldIndex : 0),
    );
    _tabController!.addListener(_handleTabChange);
    _currentTabIndex = _tabController!.index;
    setState(() {});
  }

  void _handleTabChange() {
    if (_tabController != null && !_tabController!.indexIsChanging) {
      setState(() {
        _currentTabIndex = _tabController!.index;
      });
    }
  }

  void _showErrorSnackbar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  void _showSuccessSnackbar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.green),
    );
  }

  Future<void> _showAddCategoryDialog() async {
    final nameController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add New Category'),
        content: TextField(
          controller: nameController,
          decoration: const InputDecoration(labelText: 'Category Name'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (nameController.text.trim().isNotEmpty) {
                try {
                  final newCategory = await ApiService.addCategory(nameController.text.trim());
                  setState(() {
                    categories.add({'id': newCategory['id'] as int, 'name': newCategory['name'] as String});
                    categories.sort((a, b) => (a['id'] as int).compareTo(b['id'] as int));
                  });
                  _updateTabController(initialIndex: categories.length - 1);
                  _showSuccessSnackbar('Category added successfully');
                  Navigator.pop(context);
                } catch (e) {
                  _showErrorSnackbar('Failed to add category: $e');
                }
              } else {
                _showErrorSnackbar('Category name is required');
              }
            },
            child: const Text('Confirm'),
          ),
        ],
      ),
    );
  }

  Future<void> _showDeleteCategoriesDialog() async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Categories'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: categories.length,
            itemBuilder: (context, index) {
              final category = categories[index];
              return ListTile(
                title: Text(category['name']),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () async {
                    try {
                      await ApiService.deleteCategory(category['id']);
                      setState(() {
                        categories.removeAt(index);
                      });
                      _updateTabController(initialIndex: 0);
                      _showSuccessSnackbar('Category deleted');
                      Navigator.pop(context);
                    } catch (e) {
                      _showErrorSnackbar('Failed to delete category: $e');
                    }
                  },
                ),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Future<void> _showFoodDialog({FoodItem? item, required int categoryId}) async {
    final nameController = TextEditingController(text: item?.name ?? '');
    final priceController = TextEditingController(text: item?.price.toString() ?? '');
    final stockController = TextEditingController(text: item?.stock.toString() ?? '');
    XFile? pickedImage = _selectedImage;

    await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setStateDialog) => AlertDialog(
          title: Text(item == null ? 'Add Food' : 'Edit Food'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                GestureDetector(
                  onTap: () async {
                    final picked = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 75);
                    if (picked != null) {
                      setStateDialog(() => pickedImage = picked);
                    }
                  },
                  child: pickedImage != null
                      ? (kIsWeb
                      ? Image.network(
                    pickedImage!.path,
                    width: 80,
                    height: 80,
                    fit: BoxFit.cover,
                  )
                      : Image.file(
                    File(pickedImage!.path),
                    width: 80,
                    height: 80,
                    fit: BoxFit.cover,
                  ))
                      : (item?.imagePath?.isNotEmpty ?? false
                      ? Image.network(
                    '${ApiService.uploadUrl}${item!.imagePath}',
                    width: 80,
                    height: 80,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) =>
                    const Icon(Icons.broken_image, size: 48),
                  )
                      : Container(
                    width: 80,
                    height: 80,
                    color: Colors.grey[300],
                    child: const Icon(Icons.camera_alt, size: 40),
                  )),
                ),
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(labelText: 'Name'),
                ),
                TextField(
                  controller: priceController,
                  decoration: const InputDecoration(labelText: 'Price'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: stockController,
                  decoration: const InputDecoration(labelText: 'Stock'),
                  keyboardType: TextInputType.number,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                final name = nameController.text.trim();
                final price = double.tryParse(priceController.text.trim()) ?? 0.0;
                final stock = int.tryParse(stockController.text.trim()) ?? 0;
                if (name.isEmpty || price <= 0 || stock < 0) {
                  _showErrorSnackbar('Please fill all fields correctly');
                  return;
                }

                try {
                  if (item == null) {
                    final newItem = FoodItem(
                      id: '',
                      name: name,
                      price: price,
                      stock: stock,
                      categoryId: categoryId,
                    );
                    final added = await ApiService.addFoodItem(newItem, pickedImage);
                    setState(() {
                      foodItems.add(added);
                    });
                    _showSuccessSnackbar('Food item added');
                  } else {
                    item.name = name;
                    item.price = price;
                    item.stock = stock;
                    final updated = await ApiService.updateFoodItem(item, pickedImage);
                    setState(() {
                      final idx = foodItems.indexWhere((f) => f.id == item.id);
                      if (idx != -1) foodItems[idx] = updated;
                    });
                    _showSuccessSnackbar('Food item updated');
                  }
                  Navigator.pop(context);
                } catch (e) {
                  _showErrorSnackbar('Failed to save food item: $e');
                }
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
    _selectedImage = null;
  }

  Future<void> _deleteFood(FoodItem item) async {
    if (item.id.isEmpty) {
      _showErrorSnackbar('Cannot delete item: Invalid ID');
      return;
    }
    try {
      await ApiService.deleteFoodItem(item.id);
      setState(() {
        foodItems.removeWhere((f) => f.id == item.id);
      });
      _showSuccessSnackbar('Food item deleted successfully');
    } catch (e) {
      _showErrorSnackbar('Failed to delete food item: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Smart Canteen - Food Manager'),
        actions: [
          PopupMenuButton<int>(
            icon: const Icon(Icons.more_vert),
            onSelected: (value) {
              if (value == 0) {
                _showAddCategoryDialog();
              } else if (value == 1) {
                _showDeleteCategoriesDialog();
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 0,
                child: Text('Add New Category'),
              ),
              const PopupMenuItem(
                value: 1,
                child: Text('Delete Categories'),
                enabled: true,
              ),
            ],
          ),
        ],
        bottom: categories.isEmpty || _tabController == null
            ? null
            : TabBar(
          controller: _tabController,
          tabs: categories.map((c) => Tab(text: c['name'])).toList(),
          isScrollable: true,
        ),
      ),
      body: isLoading || categories.isEmpty || _tabController == null
          ? const Center(child: CircularProgressIndicator())
          : TabBarView(
        controller: _tabController,
        children: categories.map((category) {
          final filteredItems = foodItems.where((f) => f.categoryId == category['id']).toList();
          return Column(
            children: [
              Expanded(
                child: filteredItems.isEmpty
                    ? const Center(child: Text('No items yet'))
                    : RefreshIndicator(
                  onRefresh: _loadFoodItems,
                  child: ListView.builder(
                    itemCount: filteredItems.length,
                    itemBuilder: (context, index) {
                      final item = filteredItems[index];
                      Widget imageWidget;
                      if (item.imagePath != null && item.imagePath!.isNotEmpty) {
                        imageWidget = ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            '${ApiService.uploadUrl}${item.imagePath}',
                            width: 70,
                            height: 70,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) =>
                            const Icon(Icons.broken_image, size: 48),
                          ),
                        );
                      } else {
                        imageWidget = const Icon(Icons.fastfood, size: 48);
                      }

                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        child: ListTile(
                          leading: imageWidget,
                          title: Text(item.name),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Rs. ${item.price.toStringAsFixed(2)}'),
                              Text('Stock: ${item.stock}'),
                            ],
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit),
                                onPressed: () => _showFoodDialog(
                                  item: item,
                                  categoryId: item.categoryId,
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete),
                                onPressed: () => _deleteFood(item),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          );
        }).toList(),
      ),
      floatingActionButton: categories.isEmpty || _tabController == null
          ? null
          : Builder(
        builder: (context) {
          final currentIndex = _tabController!.index;
          final currentCategory = categories[currentIndex];
          return FloatingActionButton.extended(
            onPressed: () => _showFoodDialog(categoryId: currentCategory['id']),
            label: const Text('Add Food'),
            icon: const Icon(Icons.fastfood),
          );
        },
      ),
    );
  }
}

