import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:http/http.dart' as storage;

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fingerprint Registration',
      theme: ThemeData(primarySwatch: Colors.teal, useMaterial3: true),
      home: const FingerprintRegisterPage(),
    );
  }
}

class FingerprintRegisterPage extends StatefulWidget {
  const FingerprintRegisterPage({super.key});

  @override
  State<FingerprintRegisterPage> createState() => _FingerprintRegisterPageState();
}


class _FingerprintRegisterPageState extends State<FingerprintRegisterPage> {
  final _emailController = TextEditingController();
  bool _loading = false;
  String _statusMessage = '';
  final storage = const FlutterSecureStorage(); // Initialize secure storage

  final String backendBaseUrl = 'http://localhost:8081';
  String? _jwtToken;

  @override
  void initState() {
    super.initState();
    _loadJwtToken();
  }

  Future<void> _loadJwtToken() async {
    try {
      final token = await storage.read(key: 'jwt_token'); // Corrected line
      setState(() {
        _jwtToken = token;
      });
    } catch (e) {
      setState(() {
        _statusMessage = 'Error loading authentication token: ${e.toString()}';
      });
    }
  }

  Future<void> _registerFingerprint() async {
    if (_jwtToken == null) {
      setState(() => _statusMessage = 'Not authenticated');
      return;
    }

    setState(() {
      _loading = true;
      _statusMessage = '';
    });

    try {
      final response = await http.post(
        Uri.parse('$backendBaseUrl/api/merchant/update-biometrics'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $_jwtToken',
        },
        body: jsonEncode({
          'email': _emailController.text.trim(),
        }),
      );

      if (response.statusCode == 200) {
        _statusMessage = 'Fingerprint registration initiated successfully.';
      } else {
        _statusMessage = 'Failed to initiate registration (${response.statusCode})';
      }
    } catch (e) {
      _statusMessage = 'Network error: ${e.toString()}';
    } finally {
      setState(() => _loading = false);
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Register Fingerprint'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(Icons.fingerprint, size: 100, color: Colors.teal),
            const SizedBox(height: 20),
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(
                labelText: 'Email',
                prefixIcon: Icon(Icons.email),
              ),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _loading ? null : _registerFingerprint,
              child: _loading
                  ? const CircularProgressIndicator()
                  : const Text('Continue to Registration'),
            ),
            const SizedBox(height: 20),
            Text(
              _statusMessage,
              style: TextStyle(
                color: _statusMessage.contains('Error') || _statusMessage.contains('Failed')
                    ? Colors.red
                    : Colors.green,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}