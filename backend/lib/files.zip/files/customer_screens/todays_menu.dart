import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class MenuItemModel {
  final int id;
  final String name;
  final double price;
  final String imagePath;

  MenuItemModel({
    required this.id,
    required this.name,
    required this.price,
    required this.imagePath,
  });

  factory MenuItemModel.fromJson(Map<String, dynamic> json) => MenuItemModel(
    id: json['id'],
    name: json['name'],
    price: (json['price'] as num).toDouble(),
    imagePath: json['imagePath'] ?? '',
  );
}

class TodaysMenuScreen extends StatefulWidget {
  const TodaysMenuScreen({super.key});
  @override
  State<TodaysMenuScreen> createState() => _TodaysMenuScreenState();
}

class _TodaysMenuScreenState extends State<TodaysMenuScreen> {
  final storage = const FlutterSecureStorage();

  Future<List<MenuItemModel>> fetchTodaysMenu() async {
    final token = await storage.read(key: 'jwt_token');
    final response = await http.get(
      Uri.parse('http://192.168.56.1:8081/api/customer/menu'),
      headers: {'Authorization': 'Bearer $token'},
    );
    if (response.statusCode == 200) {
      final List data = jsonDecode(response.body);
      // Only show items that are in today's menu (isInTodayMenu == true)
      final filtered = data.where((item) => item['isInTodayMenu'] == true).toList();
      return filtered.map((json) => MenuItemModel.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load menu');
    }
  }

  void _showMenuItemPopup(BuildContext context, MenuItemModel item) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(item.name),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (item.imagePath.isNotEmpty)
              Image.network('http://192.168.56.1:8081/uploads/${item.imagePath}', height: 120),
            Text('Price: \$${item.price.toStringAsFixed(2)}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final token = await storage.read(key: 'jwt_token');
              final response = await http.post(
                Uri.parse('http://192.168.56.1:8081/api/cart/add'),
                headers: {
                  'Authorization': 'Bearer $token',
                  'Content-Type': 'application/json',
                },
                body: jsonEncode({'menuItemId': item.id, 'quantity': 1}),
              );
              if (response.statusCode == 200) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Added to cart!')),
                );
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Failed: ${response.body}')),
                );
              }
              Navigator.pop(context);
            },
            child: const Text('Add to Cart'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<MenuItemModel>>(
      future: fetchTodaysMenu(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }
        final items = snapshot.data ?? [];
        if (items.isEmpty) {
          return const Center(child: Text('No menu items today.'));
        }
        return GridView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: items.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
          itemBuilder: (context, index) {
            final item = items[index];
            return GestureDetector(
              onTap: () => _showMenuItemPopup(context, item),
              child: Card(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (item.imagePath.isNotEmpty)
                      Image.network(
                        'http://192.168.56.1:8081/uploads/${item.imagePath}',
                        height: 80,
                        fit: BoxFit.cover,
                      ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6.0),
                      child: Text(item.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                    ),
                    Text('\$${item.price.toStringAsFixed(2)}'),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}
