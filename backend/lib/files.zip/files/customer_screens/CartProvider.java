import 'package:flutter/material.dart';
import 'package:food_app/models/menu_item.dart';

class CartProvider with ChangeNotifier {
  final Map<int, int> _cart = {};
  List<MenuItem> _menuItems = [];

  Map<int, int> get cart => _cart;

  /// Sets the master list of menu items to look up prices and details.
  void setMenuItems(List<MenuItem> items) {
    _menuItems = items;
  }

  /// Adds one quantity of an item to the cart or creates it if it doesn't exist.
  void addToCart(int itemId) {
    if (_cart.containsKey(itemId)) {
      _cart[itemId] = _cart[itemId]! + 1;
    } else {
      _cart[itemId] = 1;
    }
    notifyListeners();
  }

  /// Removes one quantity of an item from the cart or removes the item if quantity is 1.
  void removeFromCart(int itemId) {
    if (_cart.containsKey(itemId) && _cart[itemId]! > 1) {
      _cart[itemId] = _cart[itemId]! - 1;
    } else {
      _cart.remove(itemId);
    }
    notifyListeners();
  }
  
  /// Completely removes an item from the cart, regardless of quantity.
  void clearItemFromCart(int itemId) {
    _cart.remove(itemId);
    notifyListeners();
  }

  /// Empties the entire cart.
  void clearCart() {
    _cart.clear();
    notifyListeners();
  }

  /// Gets the current quantity of a specific item in the cart.
  int getQuantity(int itemId) {
    return _cart[itemId] ?? 0;
  }

  /// Calculates the total price of all items in the cart.
  double get totalAmount {
    double total = 0.0;
    if (_menuItems.isEmpty) return total;
    
    _cart.forEach((itemId, quantity) {
      // Find the item in the master list to get its price
      final item = _menuItems.firstWhere(
        (element) => element.id == itemId,
        orElse: () => MenuItem(id: 0, name: '', price: 0, imagePath: '', categoryId: 0),
      );
      if (item.id != 0) {
        total += item.price * quantity;
      }
    });
    return total;
  }

  /// Returns a list of MenuItem objects that are currently in the cart.
  List<MenuItem> get cartItems {
    if (_menuItems.isEmpty) return [];
    
    return _menuItems.where((item) => _cart.containsKey(item.id)).toList();
  }
}