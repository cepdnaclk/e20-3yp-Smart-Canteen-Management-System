// import 'dart:convert';
//
// import 'package:flutter/material.dart';
// import 'package:flutter_secure_storage/flutter_secure_storage.dart';
// import 'package:food_app/widgets/custom_scaffold.dart';
// import 'package:food_app/widgets/searchbar.dart';
// import 'package:food_app/widgets/highlight.dart';
// import 'package:food_app/customer_screens/budget.dart';
// import 'package:http/http.dart' as http; // Import the new MenuItem widget
//
// class HomeScreen extends StatefulWidget {
//   const HomeScreen({super.key});
//
//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }
//
// class _HomeScreenState extends State<HomeScreen> {
//   final TextEditingController searchController = TextEditingController();
//   bool isMenuVisible = false;
//   String _selectedMenu = 'Home'; // Track selected menu
//
//
//
//
//   void toggleMenu() {
//     setState(() {
//       isMenuVisible = !isMenuVisible;
//     });
//   }
//
//   void _selectMenu(String menuItem) {
//     setState(() {
//       _selectedMenu = menuItem;
//       isMenuVisible = false; // Close the menu after selection
//     });
//     // Add navigation logic here if needed
//   }
//
//   // ... inside _HomeScreenState ...
//
//   final storage = const FlutterSecureStorage();
//
//   void _showTopUpDialog(BuildContext context) {
//     final TextEditingController amountController = TextEditingController();
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('Request Top-Up'),
//         content: TextField(
//           controller: amountController,
//           keyboardType: TextInputType.number,
//           decoration: const InputDecoration(labelText: 'Amount'),
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context),
//             child: const Text('Cancel'),
//           ),
//           TextButton(
//             onPressed: () async {
//               final amount = double.tryParse(amountController.text);
//               if (amount == null || amount <= 0) {
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   const SnackBar(content: Text('Enter a valid amount')),
//                 );
//                 return;
//               }
//               final token = await storage.read(key: 'jwt_token');
//               final response = await http.post(
//                 Uri.parse('http://192.168.56.1:8081/api/topup/request'),
//                 headers: {
//                   'Authorization': 'Bearer $token',
//                   'Content-Type': 'application/json',
//                 },
//                 body: jsonEncode({'amount': amount}),
//               );
//               if (response.statusCode == 200) {
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   const SnackBar(content: Text('Request sent!')),
//                 );
//               } else {
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   SnackBar(content: Text('Failed: ${response.body}')),
//                 );
//               }
//               Navigator.pop(context);
//             },
//             child: const Text('Send'),
//           ),
//         ],
//       ),
//     );
//   }
//
//
//
//   @override
//   Widget build(BuildContext context) {
//     return CustomScaffold(
//       child: Stack(
//         children: [
//           // Main content
//           Column(
//             children: [
//               // Top row: Menu + Notification
//               Padding(
//                 padding: const EdgeInsets.only(
//                   top: 16.0,
//                   left: 8.0,
//                   right: 8.0,
//                 ),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     AnimatedSwitcher(
//                       duration: const Duration(milliseconds: 200),
//                       transitionBuilder:
//                           (child, animation) => RotationTransition(
//                             turns:
//                                 child.key == const ValueKey('menu')
//                                     ? Tween<double>(
//                                       begin: 0.75,
//                                       end: 1,
//                                     ).animate(animation)
//                                     : Tween<double>(
//                                       begin: 1,
//                                       end: 0.75,
//                                     ).animate(animation),
//                             child: FadeTransition(
//                               opacity: animation,
//                               child: child,
//                             ),
//                           ),
//                       child: IconButton(
//                         key: ValueKey(isMenuVisible ? 'close' : 'menu'),
//                         icon: Icon(
//                           isMenuVisible ? Icons.close : Icons.menu,
//                           color: Colors.black,
//                           size: 28,
//                         ),
//                         onPressed: toggleMenu,
//                       ),
//                     ),
//                     IconButton(
//                       icon: const Icon(
//                         Icons.notifications_none,
//                         color: Colors.black,
//                         size: 28,
//                       ),
//                       onPressed: () {
//                         print('Notifications tapped');
//                       },
//                     ),
//                   ],
//                 ),
//               ),
//
//               // Search bar
//               Padding(
//                 padding: const EdgeInsets.symmetric(
//                   horizontal: 16.0,
//                   vertical: 8.0,
//                 ),
//                 child: CustomSearchBar(
//                   controller: searchController,
//                   onChanged: (value) {
//                     print('Searching for: $value');
//                   },
//                 ),
//               ),
//
//               // Main content
//               const Expanded(
//                 child: Center(
//                   child: Text(
//                     "Home Content Goes Here",
//                     style: TextStyle(fontSize: 18),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//
//           // Custom side menu
//           AnimatedPositioned(
//             duration: const Duration(milliseconds: 300),
//             left: isMenuVisible ? 0 : -250,
//             top: 0,
//             bottom: 0,
//             child: Container(
//               width: 250,
//               decoration: BoxDecoration(
//                 color: Colors.white,
//                 boxShadow: [
//                   BoxShadow(
//                     color: Colors.black.withOpacity(0.2),
//                     blurRadius: 10,
//                     spreadRadius: 2,
//                   ),
//                 ],
//               ),
//               child: Column(
//                 children: [
//                   Container(
//                     height: 150,
//                     alignment: Alignment.center,
//                     color: Colors.black,
//                     child: const Text(
//                       'Menu',
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: 24,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                   ),
//                   MenuItem(
//                     icon:
//                         Icons.account_balance_wallet, // or any icon you prefer
//                     title: 'Budget',
//                     isSelected: _selectedMenu == 'Budget',
//                     onTap: () {
//                       _selectMenu('Budget');
//                       Navigator.push(
//                         context,
//                         MaterialPageRoute(
//                           builder: (context) => BudgetDashboard(),
//                         ),
//                       );
//                     },
//                   ),
//
//                   MenuItem(
//                     icon: Icons.person,
//                     title: 'Profile',
//                     isSelected: _selectedMenu == 'Profile',
//                     onTap: () => _selectMenu('Profile'),
//                   ),
//                   MenuItem(
//                     icon: Icons.settings,
//                     title: 'Settings',
//                     isSelected: _selectedMenu == 'Settings',
//                     onTap: () => _selectMenu('Settings'),
//                   ),
//                   MenuItem(
//                     icon: Icons.notifications,
//                     title: 'Notifications',
//                     isSelected: _selectedMenu == 'Notifications',
//                     onTap: () => _selectMenu('Notifications'),
//                   ),
//                   const Divider(height: 1, thickness: 1),
//                   MenuItem(
//                     icon: Icons.logout,
//                     title: 'Logout',
//                     isSelected: _selectedMenu == 'Logout',
//                     onTap: () => _selectMenu('Logout'),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//
//           // Tap to close menu overlay
//           if (isMenuVisible)
//             Positioned.fill(
//               left: 250,
//               child: GestureDetector(
//                 onTap: toggleMenu,
//                 child: Container(color: Colors.black.withOpacity(0.3)),
//               ),
//             ),
//         ],
//       ),
//     );
//
//   }
//
//
// }
 // 'http://192.168.56.1:8081/api/menu/today'

// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:flutter_secure_storage/flutter_secure_storage.dart';
// import 'package:food_app/widgets/custom_scaffold.dart';
// import 'package:food_app/widgets/searchbar.dart';
// import 'package:food_app/customer_screens/budget.dart';
// import 'package:http/http.dart' as http;
//
// class MenuItemModel {
//   final int id;
//   final String name;
//   final double price;
//   final String imagePath;
//
//   MenuItemModel({
//     required this.id,
//     required this.name,
//     required this.price,
//     required this.imagePath,
//   });
//
//   factory MenuItemModel.fromJson(Map<String, dynamic> json) => MenuItemModel(
//     id: json['id'],
//     name: json['name'],
//     price: (json['price'] as num).toDouble(),
//     imagePath: json['imagePath'] ?? '',
//   );
// }
//
// class HomeScreen extends StatefulWidget {
//   const HomeScreen({super.key});
//
//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }
//
// class _HomeScreenState extends State<HomeScreen> {
//   final TextEditingController searchController = TextEditingController();
//   final storage = const FlutterSecureStorage();
//   bool isMenuVisible = false;
//   String _selectedMenu = 'Home';
//
//   List<MenuItemModel> _allMenuItems = [];
//   List<MenuItemModel> _filteredMenuItems = [];
//   bool _loadingMenu = true;
//   String _searchError = '';
//
//   // Cart: key = menu item id, value = quantity
//   Map<int, int> cart = {};
//
//   @override
//   void initState() {
//     super.initState();
//     _fetchTodaysMenu();
//     searchController.addListener(_onSearchChanged);
//   }
//
//   @override
//   void dispose() {
//     searchController.dispose();
//     super.dispose();
//   }
//
//   void toggleMenu() {
//     setState(() {
//       isMenuVisible = !isMenuVisible;
//     });
//   }
//
//   void _selectMenu(String menuItem) {
//     setState(() {
//       _selectedMenu = menuItem;
//       isMenuVisible = false;
//     });
//     if (menuItem == 'Budget') {
//       Navigator.push(
//         context,
//         MaterialPageRoute(
//           builder: (context) => const BudgetDashboard(),
//         ),
//       );
//     }
//     // Add navigation for other menu items if needed
//   }
//
//   Future<void> _fetchTodaysMenu() async {
//     setState(() {
//       _loadingMenu = true;
//       _searchError = '';
//     });
//     try {
//       final token = await storage.read(key: 'jwt_token');
//       final response = await http.get(
//         Uri.parse('http://192.168.56.1:8081/api/menu/today'),
//         headers: {'Authorization': 'Bearer $token'},
//       );
//       if (response.statusCode == 200) {
//         final List data = jsonDecode(response.body);
//         _allMenuItems = data.map((json) => MenuItemModel.fromJson(json)).toList();
//         _filteredMenuItems = List.from(_allMenuItems);
//         setState(() {
//           _loadingMenu = false;
//           _searchError = '';
//         });
//       } else {
//         setState(() {
//           _loadingMenu = false;
//           _searchError = 'Error loading menu: ${response.body}';
//         });
//       }
//     } catch (e) {
//       setState(() {
//         _loadingMenu = false;
//         _searchError = 'Error loading menu: $e';
//       });
//     }
//   }
//
//   void _onSearchChanged() {
//     final query = searchController.text.trim().toLowerCase();
//     if (query.isEmpty) {
//       setState(() {
//         _filteredMenuItems = List.from(_allMenuItems);
//         _searchError = '';
//       });
//     } else {
//       final results = _allMenuItems.where((item) =>
//           item.name.toLowerCase().contains(query)).toList();
//       setState(() {
//         _filteredMenuItems = results;
//         _searchError = results.isEmpty ? 'Item not found or available.' : '';
//       });
//     }
//   }
//
//   void _toggleCart(MenuItemModel item) {
//     setState(() {
//       if (cart.containsKey(item.id)) {
//         cart.remove(item.id);
//       } else {
//         cart[item.id] = 1;
//       }
//     });
//   }
//
//   void _showCart() {
//     showModalBottomSheet(
//       context: context,
//       builder: (context) {
//         final cartItems = _allMenuItems.where((item) => cart.containsKey(item.id)).toList();
//         double total = cartItems.fold(0, (sum, item) => sum + item.price * (cart[item.id] ?? 1));
//         return SizedBox(
//           height: 350,
//           child: Column(
//             children: [
//               const SizedBox(height: 10),
//               const Text('Your Cart', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
//               const Divider(),
//               Expanded(
//                 child: cartItems.isEmpty
//                     ? const Center(child: Text('Cart is empty'))
//                     : ListView.builder(
//                   itemCount: cartItems.length,
//                   itemBuilder: (context, index) {
//                     final item = cartItems[index];
//                     return ListTile(
//                       leading: item.imagePath.isNotEmpty
//                           ? Image.network(
//                           'http://192.168.56.1:8081/uploads/${item.imagePath}',
//                           width: 40, height: 40, fit: BoxFit.cover)
//                           : null,
//                       title: Text(item.name),
//                       subtitle: Text('\$${item.price.toStringAsFixed(2)}'),
//                       trailing: IconButton(
//                         icon: const Icon(Icons.remove_circle, color: Colors.red),
//                         onPressed: () {
//                           setState(() {
//                             cart.remove(item.id);
//                           });
//                           Navigator.pop(context);
//                           _showCart();
//                         },
//                       ),
//                     );
//                   },
//                 ),
//               ),
//               const Divider(),
//               Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     const Text('Total:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
//                     Text('\$${total.toStringAsFixed(2)}',
//                         style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
//                   ],
//                 ),
//               ),
//               ElevatedButton(
//                 onPressed: cartItems.isEmpty ? null : _placeOrder,
//                 child: const Text('Place Order'),
//               ),
//               const SizedBox(height: 10),
//             ],
//           ),
//         );
//       },
//     );
//   }
//
//   Future<void> _placeOrder() async {
//     final token = await storage.read(key: 'jwt_token');
//     // <-- store user ID at login
//     if (token == null) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('Error. Please log in again.')),
//       );
//       return;
//     }
//
//     final items = { for (var e in cart.entries) e.key.toString(): e.value };
//     try {
//       final response = await http.post(
//         Uri.parse('http://192.168.56.1:8081/api/orders/place'),
//         headers: {
//           'Authorization': 'Bearer $token',
//           'Content-Type': 'application/json',
//         },
//         body: jsonEncode({
//           'email': await storage.read(key: 'orderemail'),      // <-- include userId here
//           'items': items
//         }),
//       );
//       if (response.statusCode == 200) {
//         setState(() {
//           cart.clear();
//         });
//         Navigator.pop(context);
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(content: Text('Order placed successfully!')),
//         );
//       } else {
//         ScaffoldMessenger.of(context).showSnackBar(
//           SnackBar(content: Text('Failed to place order: ${response.body}')),
//         );
//       }
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Error: $e')),
//       );
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return CustomScaffold(
//       child: Stack(
//         children: [
//           Column(
//             children: [
//               // Top row: Menu + Notification + Cart
//               Padding(
//                 padding: const EdgeInsets.only(top: 16.0, left: 8.0, right: 8.0),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     AnimatedSwitcher(
//                       duration: const Duration(milliseconds: 200),
//                       transitionBuilder: (child, animation) => RotationTransition(
//                         turns: child.key == const ValueKey('menu')
//                             ? Tween<double>(begin: 0.75, end: 1).animate(animation)
//                             : Tween<double>(begin: 1, end: 0.75).animate(animation),
//                         child: FadeTransition(
//                           opacity: animation,
//                           child: child,
//                         ),
//                       ),
//                       child: IconButton(
//                         key: ValueKey(isMenuVisible ? 'close' : 'menu'),
//                         icon: Icon(
//                           isMenuVisible ? Icons.close : Icons.menu,
//                           color: Colors.black,
//                           size: 28,
//                         ),
//                         onPressed: toggleMenu,
//                       ),
//                     ),
//                     IconButton(
//                       icon: const Icon(Icons.shopping_cart, color: Colors.black, size: 28),
//                       onPressed: _showCart,
//                     ),
//                   ],
//                 ),
//               ),
//               // Search bar
//               Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
//                 child: CustomSearchBar(
//                   controller: searchController,
//                   onChanged: (value) => _onSearchChanged(),
//                 ),
//               ),
//               // Main content: Menu items from today's menu
//               Expanded(
//                 child: _loadingMenu
//                     ? const Center(child: CircularProgressIndicator())
//                     : _searchError.isNotEmpty
//                     ? Center(child: Text(_searchError))
//                     : _filteredMenuItems.isEmpty
//                     ? const Center(child: Text('No menu items today.'))
//                     : GridView.builder(
//                   padding: const EdgeInsets.all(16),
//                   itemCount: _filteredMenuItems.length,
//                   gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//                       crossAxisCount: 2),
//                   itemBuilder: (context, index) {
//                     final item = _filteredMenuItems[index];
//                     final inCart = cart.containsKey(item.id);
//                     return GestureDetector(
//                       onTap: () => _toggleCart(item),
//                       child: Card(
//                         color: inCart ? Colors.green[50] : null,
//                         child: Column(
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           children: [
//                             if (item.imagePath.isNotEmpty)
//                               Image.network(
//                                 'http://192.168.56.1:8081/uploads/${item.imagePath}',
//                                 height: 80,
//                                 fit: BoxFit.cover,
//                               ),
//                             Padding(
//                               padding: const EdgeInsets.symmetric(vertical: 6.0),
//                               child: Text(item.name,
//                                   style: const TextStyle(fontWeight: FontWeight.bold)),
//                             ),
//                             Text('\$${item.price.toStringAsFixed(2)}'),
//                             Icon(
//                               inCart ? Icons.check_circle : Icons.add_circle_outline,
//                               color: inCart ? Colors.green : Colors.grey,
//                             ),
//                           ],
//                         ),
//                       ),
//                     );
//                   },
//                 ),
//               ),
//             ],
//           ),
//           // Custom side menu
//           AnimatedPositioned(
//             duration: const Duration(milliseconds: 300),
//             left: isMenuVisible ? 0 : -250,
//             top: 0,
//             bottom: 0,
//             child: Container(
//               width: 250,
//               decoration: BoxDecoration(
//                 color: Colors.white,
//                 boxShadow: [
//                   BoxShadow(
//                     color: Colors.black.withOpacity(0.2),
//                     blurRadius: 10,
//                     spreadRadius: 2,
//                   ),
//                 ],
//               ),
//               child: Column(
//                 children: [
//                   Container(
//                     height: 150,
//                     alignment: Alignment.center,
//                     color: Colors.black,
//                     child: const Text(
//                       'Menu',
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: 24,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                   ),
//                   MenuItem(
//                     icon: Icons.account_balance_wallet,
//                     title: 'Budget',
//                     isSelected: _selectedMenu == 'Budget',
//                     onTap: () {
//                       _selectMenu('Budget');
//                     },
//                   ),
//                   MenuItem(
//                     icon: Icons.person,
//                     title: 'Profile',
//                     isSelected: _selectedMenu == 'Profile',
//                     onTap: () => _selectMenu('Profile'),
//                   ),
//                   MenuItem(
//                     icon: Icons.settings,
//                     title: 'Settings',
//                     isSelected: _selectedMenu == 'Settings',
//                     onTap: () => _selectMenu('Settings'),
//                   ),
//                   MenuItem(
//                     icon: Icons.notifications,
//                     title: 'Notifications',
//                     isSelected: _selectedMenu == 'Notifications',
//                     onTap: () => _selectMenu('Notifications'),
//                   ),
//                   const Divider(height: 1, thickness: 1),
//                   MenuItem(
//                     icon: Icons.logout,
//                     title: 'Logout',
//                     isSelected: _selectedMenu == 'Logout',
//                     onTap: () => _selectMenu('Logout'),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//           if (isMenuVisible)
//             Positioned.fill(
//               left: 250,
//               child: GestureDetector(
//                 onTap: toggleMenu,
//                 child: Container(color: Colors.black.withOpacity(0.3)),
//               ),
//             ),
//         ],
//       ),
//     );
//   }
// }
//
// class MenuItem extends StatelessWidget {
//   final IconData icon;
//   final String title;
//   final bool isSelected;
//   final VoidCallback onTap;
//
//   const MenuItem({
//     super.key,
//     required this.icon,
//     required this.title,
//     required this.isSelected,
//     required this.onTap,
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return ListTile(
//       leading: Icon(icon, color: isSelected ? Colors.deepPurple : Colors.black),
//       title: Text(
//         title,
//         style: TextStyle(
//           color: isSelected ? Colors.deepPurple : Colors.black,
//           fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
//         ),
//       ),
//       onTap: onTap,
//     );
//   }
// }
//
//

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:food_app/widgets/custom_scaffold.dart';
import 'package:food_app/widgets/searchbar.dart';
import 'package:food_app/customer_screens/budget.dart';
import 'package:http/http.dart' as http;
import 'package:food_app/screens/login_screen.dart';

import '../screens/welcome_screen.dart';

//import 'budget1.dart';

class MenuItemModel {
  final int id;
  final String name;
  final double price;
  final String imagePath;

  MenuItemModel({
    required this.id,
    required this.name,
    required this.price,
    required this.imagePath,
  });

  factory MenuItemModel.fromJson(Map<String, dynamic> json) => MenuItemModel(
    id: json['id'],
    name: json['name'],
    price: (json['price'] as num).toDouble(),
    imagePath: json['imagePath'] ?? '',
  );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController searchController = TextEditingController();
  final storage = const FlutterSecureStorage();
  bool isMenuVisible = false;
  String _selectedMenu = 'Home';

  List<MenuItemModel> _allMenuItems = [];
  List<MenuItemModel> _filteredMenuItems = [];
  bool _loadingMenu = true;
  String _searchError = '';

  // Cart: key = menu item id, value = quantity
  Map<int, int> cart = {};



  @override
  void initState() {
    super.initState();
    _fetchTodaysMenu();
    searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  void toggleMenu() {
    setState(() {
      isMenuVisible = !isMenuVisible;
    });
  }

  void _selectMenu(String menuItem) {
    setState(() {
      _selectedMenu = menuItem;
      isMenuVisible = false;
    });
    if (menuItem == 'Budget') {
      Navigator.push(
        context,
        MaterialPageRoute(
          //builder: (context) => const BudgetDashboard(),
          builder: (context) => const BudgetDashboard(),
        ),
      );
    }
    // Add navigation for other menu items if needed
  }

  Future<void> _fetchTodaysMenu() async {
    setState(() {
      _loadingMenu = true;
      _searchError = '';
    });
    try {
      final token = await storage.read(key: 'jwt_token');
      final response = await http.get(
        Uri.parse('http://192.168.56.1:8081/api/menu/today'),
        headers: {'Authorization': 'Bearer $token'},
      );
      if (response.statusCode == 200) {
        final List data = jsonDecode(response.body);
        _allMenuItems = data.map((json) => MenuItemModel.fromJson(json)).toList();
        _filteredMenuItems = List.from(_allMenuItems);
        setState(() {
          _loadingMenu = false;
          _searchError = '';
        });
      } else {
        setState(() {
          _loadingMenu = false;
          _searchError = 'Error loading menu: ${response.body}';
        });
      }
    } catch (e) {
      setState(() {
        _loadingMenu = false;
        _searchError = 'Error loading menu: $e';
      });
    }
  }

  void _onSearchChanged() {
    final query = searchController.text.trim().toLowerCase();
    if (query.isEmpty) {
      setState(() {
        _filteredMenuItems = List.from(_allMenuItems);
        _searchError = '';
      });
    } else {
      final results = _allMenuItems.where((item) =>
          item.name.toLowerCase().contains(query)).toList();
      setState(() {
        _filteredMenuItems = results;
        _searchError = results.isEmpty ? 'Item not found or available.' : '';
      });
    }
  }

  void _toggleCart(MenuItemModel item) {
    setState(() {
      if (cart.containsKey(item.id)) {
        cart.remove(item.id);
      } else {
        cart[item.id] = 1;
      }
    });
  }

  void _showCart() {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        final cartItems = _allMenuItems.where((item) => cart.containsKey(item.id)).toList();
        double total = cartItems.fold(0, (sum, item) => sum + item.price * (cart[item.id] ?? 1));
        return SizedBox(
          height: 350,
          child: Column(
            children: [
              const SizedBox(height: 10),
              const Text('Your Cart', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const Divider(),
              Expanded(
                child: cartItems.isEmpty
                    ? const Center(child: Text('Cart is empty'))
                    : ListView.builder(
                  itemCount: cartItems.length,
                  itemBuilder: (context, index) {
                    final item = cartItems[index];
                    return ListTile(
                      leading: item.imagePath.isNotEmpty
                          ? Image.network(
                          'http://192.168.56.1:8081/uploads/${item.imagePath}',
                          width: 40, height: 40, fit: BoxFit.cover)
                          : null,
                      title: Text(item.name),
                      subtitle: Text('\$${item.price.toStringAsFixed(2)}'),
                      trailing: IconButton(
                        icon: const Icon(Icons.remove_circle, color: Colors.red),
                        onPressed: () {
                          setState(() {
                            cart.remove(item.id);
                          });
                          Navigator.pop(context);
                          _showCart();
                        },
                      ),
                    );
                  },
                ),
              ),
              const Divider(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Total:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    Text('\$${total.toStringAsFixed(2)}',
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
              ElevatedButton(
                onPressed: cartItems.isEmpty ? null : _placeOrder,
                child: const Text('Place Order'),
              ),
              const SizedBox(height: 10),
            ],
          ),
        );
      },
    );
  }



  Future<void> _placeOrder() async {
    final token = await storage.read(key: 'jwt_token');
    final email = await storage.read(key: 'email'); // Fetch the user's email

    if (token == null || email == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error: Authentication required. Please log in again.')),
      );
      return;
    }

    // Prepare the items map: {itemId: quantity}
    final items = <String, int>{};
    cart.forEach((key, value) {
      items[key.toString()] = value;
    });

    try {
      final response = await http.post(
        Uri.parse('http://192.168.56.1:8081/api/orders/place'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'email': email, // Send the user's email
          'items': items, // Send the cart items
        }),
      );

      if (response.statusCode == 200) {
        setState(() {
          cart.clear();
        });
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Order placed successfully!')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to place order: ${response.body}')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error occurred: $e')),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      child: Stack(
        children: [
          Column(
            children: [
              // Top row: Menu + Notification + Cart
              Padding(
                padding: const EdgeInsets.only(top: 16.0, left: 8.0, right: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 200),
                      transitionBuilder: (child, animation) => RotationTransition(
                        turns: child.key == const ValueKey('menu')
                            ? Tween<double>(begin: 0.75, end: 1).animate(animation)
                            : Tween<double>(begin: 1, end: 0.75).animate(animation),
                        child: FadeTransition(
                          opacity: animation,
                          child: child,
                        ),
                      ),
                      child: IconButton(
                        key: ValueKey(isMenuVisible ? 'close' : 'menu'),
                        icon: Icon(
                          isMenuVisible ? Icons.close : Icons.menu,
                          color: Colors.black,
                          size: 28,
                        ),
                        onPressed: toggleMenu,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.shopping_cart, color: Colors.black, size: 28),
                      onPressed: _showCart,
                    ),
                  ],
                ),
              ),
              // Search bar
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: CustomSearchBar(
                  controller: searchController,
                  onChanged: (value) => _onSearchChanged(),
                ),
              ),
              // Main content: Menu items from today's menu
              Expanded(
                child: _loadingMenu
                    ? const Center(child: CircularProgressIndicator())
                    : _searchError.isNotEmpty
                    ? Center(child: Text(_searchError))
                    : _filteredMenuItems.isEmpty
                    ? const Center(child: Text('No menu items today.'))
                    : GridView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _filteredMenuItems.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2),
                  itemBuilder: (context, index) {
                    final item = _filteredMenuItems[index];
                    final inCart = cart.containsKey(item.id);
                    return GestureDetector(
                      onTap: () => _toggleCart(item),
                      child: Card(
                        color: inCart ? Colors.green[50] : null,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            if (item.imagePath.isNotEmpty)
                              Image.network(
                                'http://192.168.56.1:8081/uploads/${item.imagePath}',
                                height: 80,
                                fit: BoxFit.cover,
                              ),
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 6.0),
                              child: Text(item.name,
                                  style: const TextStyle(fontWeight: FontWeight.bold)),
                            ),
                            Text('\$${item.price.toStringAsFixed(2)}'),
                            Icon(
                              inCart ? Icons.check_circle : Icons.add_circle_outline,
                              color: inCart ? Colors.green : Colors.grey,
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
          // Custom side menu
          AnimatedPositioned(
            duration: const Duration(milliseconds: 300),
            left: isMenuVisible ? 0 : -250,
            top: 0,
            bottom: 0,
            child: Container(
              width: 250,
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 10,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Column(
                children: [
                  Container(
                    height: 150,
                    alignment: Alignment.center,
                    color: Colors.black,
                    child: const Text(
                      'Menu',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  MenuItem(
                    icon: Icons.account_balance_wallet,
                    title: 'Budget',
                    isSelected: _selectedMenu == 'Budget',
                    onTap: () {
                      _selectMenu('Budget');
                    },
                  ),
                  MenuItem(
                    icon: Icons.app_registration, // Registration icon
                    title: 'Request Registration',
                    isSelected: _selectedMenu == 'Request Registration',
                    onTap: () => _selectMenu('Request Registration'),
                  ),





                  ////////////////////////////////////////////////////////////////

                  ////////////////////////////////////////////////////////////////

                  const Divider(height: 1, thickness: 1), MenuItem(
    icon: Icons.logout,
    title: 'Logout',
    isSelected: _selectedMenu == 'Logout',
    onTap: () {
    Navigator.pushAndRemoveUntil(
    context,
    MaterialPageRoute(builder: (context) => WelcomeScreen()),
    (Route<dynamic> route) => false,
    );
    },
    ),
                ],
              ),
            ),
          ),
          if (isMenuVisible)
            Positioned.fill(
              left: 250,
              child: GestureDetector(
                onTap: toggleMenu,
                child: Container(color: Colors.black.withOpacity(0.3)),
              ),
            ),
        ],
      ),
    );
  }
}

class MenuItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final bool isSelected;
  final VoidCallback onTap;

  const MenuItem({
    super.key,
    required this.icon,
    required this.title,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: isSelected ? Colors.deepPurple : Colors.black),
      title: Text(
        title,
        style: TextStyle(
          color: isSelected ? Colors.deepPurple : Colors.black,
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
        ),
      ),
      onTap: onTap,
    );
  }
}











